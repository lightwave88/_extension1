
debugger;
const $g = require('./t2.js');
console.dir($g);
