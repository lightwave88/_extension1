
debugger;
const _ = require('underscore');
require('_extension').expand(_);

debugger;
let p = _.promise((res, rej) => {
    res(5);
});

p.then((d) => {
    console.log(d);
});
