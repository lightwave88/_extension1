const { MessageChannel, Worker } = require('worker_threads');
const $path = require('path');


let workerPath = $path.resolve(__dirname, './child_1.js');



debugger;
let w_1 = new Worker(workerPath, {
    workerData: {}
});


w_1.on('message', (e) => {
    debugger;
    console.dir(e);
    console.log('recieve msg(%s)', e);
});

w_1.on('exit', () => {
    debugger;
    console.log('end');
});

w_1.on('error', (er) => {
    debugger;
    console.dir(er);
});



debugger;
w_1.postMessage("hi");

let p = w_1.terminate();

p.then(() => {
    debugger;
});
