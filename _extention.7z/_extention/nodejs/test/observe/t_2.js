const $util = require('util')

require('_extension').expand('underscore');
const _ = require('underscore');

let data = {};

data = _.observe.ob(data);

_.observe.watch(data,'*.age', function(e){
    debugger;
    
    console.dir(e);
});

debugger;
data['age'] = 15;

delete data['age'];


