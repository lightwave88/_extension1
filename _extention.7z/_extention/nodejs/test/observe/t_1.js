

function getP(){
	return new Promise((res, rej)=>{

		let n = Math.random();
		setTimeout(()=> {
			res(n);
		}, 0);
	});
}

async function main(){
	debugger;

	const list = [];

	list.push(getP());
	list.push(getP());

	let d = await Promise.all(list);

	console.dir(d);

	d = await getP();

	console.dir(d);
}

main();
