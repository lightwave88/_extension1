const $util = require('util');
debugger;

let str = `aa<%aaa
bbb

ccc%>ff`;

console.log(str);
console.log($util.inspect(str));

let reg = /(<%)[^z]*/g;

str = str.replace(reg, (m, g1) => {
    debugger;

    return m;
});

console.log(str);
