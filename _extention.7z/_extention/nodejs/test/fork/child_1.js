debugger;
const $t = require('test_1');

console.dir($t);

let i = 0;
let h = setInterval(() => {
    process.send(i++);
}, 500);

process.on('message', function (m) {
    console.log('exit');
    clearInterval(h);
    process.exit();
});



