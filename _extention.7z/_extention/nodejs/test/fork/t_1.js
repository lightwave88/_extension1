const $path = require('path');

const child_process = require('child_process');

let path = $path.resolve(__dirname, './child_1.js');

// process.execArgv.push('--inspect-brk=9229');

let options = {};

Object.assign(options, { execArgv: ["--inspect-brk=9229"] });

var n = child_process.fork(path, [], options);
debugger;
n.on('message', function (m) {
    console.log('parent:%s', m);
});


setTimeout(function () {
    n.send('');
}, 10000);

