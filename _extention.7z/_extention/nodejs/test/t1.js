
debugger;
const _ = require('underscore');

debugger;
require('_extension').expand(_);

debugger;
let p = _.deferred();
p.resolve(5);





p.then((d)=>{
    debugger;
    console.dir(d);
},(er)=>{
    debugger;
    console.dir(er);
});







