const x = {
    age: 15,
    callback: null,
    getAge(){
        return this.age;
    }
};

let UID = 0;

x[`$#-W-(${UID++})-#$`] = null;

console.dir(x);