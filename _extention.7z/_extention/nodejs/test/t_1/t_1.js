console.dir(this);

console.dir(global);



console.dir(process);

debugger;
console.log('end');
