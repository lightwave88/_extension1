debugger;
function a() {
    debugger;
    console.log('a_1');
}

function b() {
    debugger;
    console.log('b_1');
}

function c() {
    debugger;
    console.log('c_1');
}

//----------------------------
const fun_1 = (() => {

    // new Function() 無法讀到外部變數
    // scope = this
    let fun = new Function(`   

    function a(){
        debugger;
        console.log('a_2');
    }

    // 目標涵式
    return function(){
        debugger;

        try {
            a();
        } catch (error) {
         console.log(error);   
        }
    
        debugger;
        try {
            b();
        } catch (error) {
            console.log(error);
        }
        
        debugger;
        try {
            c();
        } catch (error) {
            console.log(error);
        }
        console.log('hi');
    };`);

    return fun();
})();

//----------------------------
debugger;
const fun_2 = (() => {
    debugger;

    function a() {
        debugger;
        console.log('a_2');
    }

    // 目標涵式
    return function () {
        debugger;

        try {
            a();
        } catch (error) {
            console.log(error);
        }

        debugger;
        try {
            b();
        } catch (error) {
            console.log(error);
        }

        debugger;
        try {
            c();
        } catch (error) {
            console.log(error);
        }
        console.log('hi');
    };
})();
//----------------------------
function env(fn) {
    // 不會被 fn 呼叫
    function b() {
        debugger;
        console.log('b_2');
    }
    debugger;

    // fn 無法讀到 b_2
    fn();
}
//----------------------------
debugger;
env(fun_1);

debugger;
env(fun_2);