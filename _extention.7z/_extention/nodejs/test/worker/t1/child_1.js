const { parentPort, workerData } = require('worker_threads');
const $util = require('util');

debugger;
console.log('child worker>>');



parentPort.on('message', (event) => {
    debugger;

    let res = typeof(event);

    parentPort.postMessage(res);    
});

