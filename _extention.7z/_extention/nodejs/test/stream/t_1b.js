const { Readable, Writable } = require("stream");

class X extends Readable {

    constructor(options) {
        debugger;
        super(options);

        this.$re = readData.call(this, 95);
    }

    _read(size) {
        // debugger;
        console.log('_read');


        // debugger;
        // while (true) {
            let { value, done } = this.$re.next();

            if (done) {
                console.log('end');
                this.push(null);
            } else if (value === false) {
                console.log('read 内部阻塞');
                // 壓入太多了
                // 不要再 push() 了
                // 到時會再呼叫一次 _read()

            }
            // break;
        // }

    }
}

function* readData(count) {
    let count_1 = 0;

    // debugger;
    for (let i = 0; i < count; i++) {
        // debugger;
        for (let j = 0; j < 100; j++) {

            let value = count_1++;
            let res = this.push(String(value));
            // debugger;
            console.log('push(%s) status(%s)', value, res);

            yield res;

        }
    }
}

class Y extends Writable {
    constructor(options) {
        super(options);

        this.prev;
    }

    _write(chunk, en, close) {
        // debugger;

        let value = Number(chunk.toString('utf8'));

        if (Math.abs(value - this.prev) > 1) {
            console.log('lose data after(%s)', this.prev);
        }

        setTimeout(() => {
            console.log('_write(%s)', value);
            this.prev = value;
            close(null);
        }, 10);
    }
}



function t_1() { 
    let rs = new X();
    let ws = new Y();

    rs.pipe(ws);
 }

function t_2() {
    debugger;

    let rs = new X();
    let ws = new Y();

    rs.on('data', (chunk) => {

        console.log('on data(%s)', chunk.toString('utf8'));

        if (!ws.write(chunk)) {
            console.log('write 寫入阻塞');
            rs.pause()
        }
    });

    ws.on('drain', () => {
        console.log('on drain');
        rs.resume();
    });


}

t_1();