const { parentPort, workerData } = require('worker_threads');


setInterval(() => {
    parentPort.postMessage({});
}, 100);
