console.log('child');

let h;

process.on('message', function (m) {


    switch (m) {
        case 'end':
            console.log('process exit');
            clearInterval(h);
            process.exit();
            break;
        case 'start':
            h = setInterval(() => {
                process.send({});
            }, 50);
            break;

        default:
            break;
    }


});



