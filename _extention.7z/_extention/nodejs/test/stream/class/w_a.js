const { Writable } = require('stream');

// 統計資料量
// end 事件無法被呼叫?
// 須再研究
class W_a extends Writable {
    static getInstance() {
        return new W_a();
    }

    constructor(options) {
        super(options);

        this.count = 0;

        this.on('end', () => {
            // 無法被啓動
            // 再瞭解
            console.log('total=%s', this.count);
        });
    }

    _write(chunk, en, close) {
        // debugger;
        this.count += chunk.length;


        // console.log(chunk.toString('utf8'));

        close(null);


    }
}

module.exports = W_a;