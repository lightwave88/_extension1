
const x = 12;

export default x;