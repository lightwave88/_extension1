import x from './module_1.js';

console.log(x);