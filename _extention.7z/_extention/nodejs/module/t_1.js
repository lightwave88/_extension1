debugger;
const G = require('test_1');

debugger;
console.dir(G);