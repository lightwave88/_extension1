(() => {
    job_1();

    job_2();
})();


function job_1() {
    debugger;
    let search = location.search;
    let query = '';

    if (search != null && search.length) {
        query = search.replace(/^\?/, '');
    }

    let queryList = query.split('&');
    let queryMap = {};

    queryList.forEach((str) => {
        let list = str.split('=');
        list[1] = (list[1] == null) ? '' : list[1];

        if (list[0].length) {
            queryMap[list[0]] = list[1];
        }
    });

    if ('timestamp' in queryMap) {
        return;
    }

    queryMap['timestamp'] = (new Date()).getTime();

    queryList.length = 0;
    for (let k in queryMap) {
        queryList.push(`${k}=${queryMap[k]}`);
    }

    debugger;
    search = queryList.join('&');
    location.search = "?" + search;
}

function job_2() {
    let bodyDom = document.querySelector('body');

    if (bodyDom == null) {
        return;
    }

    let target = bodyDom.querySelector('div.pageReset');

    if (target != null) {
        return;
    }

    target = document.createElement('div');
    target.className = 'pageReset';

    target.innerHTML = '<button>resetPage</button>';
    bodyDom.insertBefore(target, bodyDom.firstChild);

    let buttom = target.querySelector('button');
    buttom.addEventListener('click', function (e) {
        let href = location.href;
        href = href.replace(/\?[^]*$/, '');
        href = href.replace(/#[^]*$/, '');
        location.href = href;
    });
}