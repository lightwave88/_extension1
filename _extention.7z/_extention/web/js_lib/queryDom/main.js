export { queryDom };

function queryDom(dom) {
    debugger;

    const query = QueryDom.getInstance();

    return query.query(dom);
};

// 採用深度探索的方式
class QueryDom {
    static getInstance() {
        return new QueryDom();
    }

    constructor() {
        this.levelList = [];

        // 查詢結果列表
        this.queryList = [];
    }

    query(dom) {

        let node;
        // let searchIndex;

        node = DNode.getInstance({
            level: 0,
            dom: dom,
            levelList: (this.levelList)
        });

        while (true) {
            if (node == null) {
                break;
            }

            this.record(node);

            let current = node;
            // 重點
            // 往下一層
            let next = node.nextLevel();

            if (next != null) {

                if (!(next instanceof DNode)) {
                    node = DNode.getInstance({
                        level: (current.level + 1),
                        dom: next,
                        levelList: (current.levelList),
                        parent: current,
                    });
                }
                continue;
            }

            // 若無法往下一層
            // 先回到 parent，parent 會探索下一個 child
            node = current.parent;
        }

        return this.queryList;
    }

    record(node) {
        if (node.isChecked()) {
            return;
        }
        this.queryList.push(node.dom);
    }
}

class DNode {

    static getInstance(dom, parent) {
        return new DNode(dom, parent);
    }

    constructor(options) {
        const { level, dom, parent, levelList } = options;

        this.levelList = levelList;
        this.hasChecked = false;
        this.level = level;
        this.dom = dom;
        this.childNodes = [];
        this.parent = (parent instanceof DNode) ? parent : null;

        // 檢查過的 child
        this.checkIndex = 0;

        this._init();
    }

    _init() {
        debugger;

        // 可記録階層多深
        this.levelList[this.level] = true;

        const parent = this;

        try {
            debugger;
            this.childNodes = Array.from(this.dom.childNodes);

        } catch (error) { }
    }

    isChecked() {
        const res = this.hasChecked;
        this.hasChecked = true;
        return res;
    }

    // 重點
    // 若無孩子可往下一層探索
    // 就回到 parent
    nextLevel() {
        let node = this.childNodes.shift();
        return node;
    }
}