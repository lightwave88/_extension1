import { NodeClass } from './node_1.js';

const Type1Node = NodeClass.Type1Node;
const Type2Node = NodeClass.Type2Node;

//==============================================================================
// includeRoot:輸出的內容包含 root
// rule: 給與自訂規則
function innerHTML(dom, includeRoot) {
    let api = new API();

    return api.main(dom, includeRoot);
}

export { innerHTML };

//==============================================================================
class API {

    constructor() {

        this.nodeList = [];

        this.checkRule;
    }
    //-------------------------------------------
    // includeRoot:輸出的內容包含 root
    // rule: 給與自訂規則
    main(dom, includeRoot) {

        includeRoot = !!includeRoot;

        let htmlContent;
        let node = new Type1Node(dom);
        this.nodeList.push(node);

        let i = 0;
        while (i < this.nodeList.length) {
            debugger;

            let parentNode = this.nodeList[i];
            let parentDom = parentNode.dom;

            //-----------------------
            if ('innerText' in parentDom) {
                // 檢測 innerHTML
                let r = this._hasScriptContent(parentDom.innerText);

                debugger;
                if (!r) {

                    // console.log('(%d)%s', ++j, parentDom.innerHTML);
                    // 若子孫沒有包含 script
                    // 壓縮成 textNode
                    // 轉換節點
                    this.nodeList[i] = new Type2Node(parentNode);

                    ++i;
                    continue;
                }
            }
            //-----------------------
            let childs = parentDom.childNodes;

            if (childs != null && childs.length > 0) {

                childs = Array.from(childs);
                childs.forEach(function (dom, i) {
                    // debugger;
                    let node = new Type1Node(dom, parentNode, i);
                    this.nodeList.push(node);
                }, this);
            }
            ++i;
        }
        //----------------------------
        debugger;
        for (let i = (this.nodeList.length - 1); i >= 0; i--) {
            debugger;
            let node = this.nodeList[i];

            if (node.parent != null) {
                node.callParent(node.parent);
            }

        }
        debugger;

        let root = this.nodeList[0];

        if (includeRoot) {
            htmlContent = root.getAllContent();
        } else {
            htmlContent = root.getChildContent();
        }

        return htmlContent;
    }
    //-------------------------------------------
    // 檢查 dom.text 內是否有 <% %>
    // 不用管 attr
    // 若沒有可以直接取 innerHTML
    // 避免耗時運算
    _hasScriptContent(innerText) {

        let reg = /<%[\s\S]*?%>/;
        return innerHTML.test(reg);
    }
    //-------------------------------------------
}
