
// 設定選項
const settings = {
    useSessionStorage: false
};


export { settings };