
// 把 commend 回復為原本的 script 標簽
class TransCommet2Script {

    static getCommends(root) {
        const o = new TransCommet2Script();
        return o.getCommends(root);
    }

    constructor() {

    }

    // 給一個節點
    // 依照順序抓取 commend 節點
    getCommends(root) {
        let commentList = [];

        let dataList = [root];

        let i = 0;
        let node;
        while (null != (node = dataList[i++])) {
            // debugger;


            if (node.tagName != null) {
                node.childNodes.forEach((child, i) => {
                    dataList.push(child);
                });
            } else {
                if (node.nodeType == 8) {
                    let parent = node.parentNode;
                    commentList.push({
                        parent: parent,
                        node: node
                    });
                }
            }
        } // endWhile
        // debugger;
        console.dir(commentList);

        return commentList;
    }
}