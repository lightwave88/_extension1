
// 把 commend 回復為原本的 script 標簽
class TransCommet2Script {

    // 給一個節點
    // 依照順序抓取 commend 節點
    getCommends(root) {
        let commentList = [];

        let dataList = [{
            level: [1],
            node: root
        }];

        // 位數
        let digit = dataList[0].level.length;

        let i = 0;
        let data;
        while (null != (data = dataList[i++])) {
            // debugger;

            const level = data.level;
            const node = data.node;

            if (node.tagName != null) {
                node.childNodes.forEach((child, i) => {
                    let _level = level.slice()
                    _level.push(i + 1);

                    if (_level.length > digit) {
                        digit = _level.length;
                    }

                    dataList.push({
                        level: _level,
                        node: child
                    });
                });
            } else {
                if (node.nodeType == 8) {
                    let parent = node.parentNode;
                    commentList.push({
                        parent: parent,
                        node: node,
                        level
                    });
                }
            }
        } // endWhile
        // debugger;
        console.dir(commentList);

        commentList.sort((a, b) => {
            if (Array.isArray(a.level)) {
                a.level = this._getLevel(digit, a.level);
            }

            if (Array.isArray(b.level)) {
                b.level = this._getLevel(digit, b.level);
            }

            return (a.level - b.level);
        });

        console.dir(commentList);

        // let resList = commentList.map(data => {
        //     return data.node;
        // });
        return commentList;
    }

    // 正確取得每個 node 的位置順序權重
    _getLevel(digit, level) {
        // debugger;
        let j = digit - level.length;

        // debugger;
        // 基數
        let p = 1;
        for (let i = 0; i < j; i++) {
            p *= 10;
        }

        // debugger;
        let res = 0;
        let num;
        while (null != (num = level.pop())) {
            res = res + num * p;
            // 十進位
            p *= 10;
        }

        return res;
    }
}