debugger;
import { t1 } from './t1.js';

debugger;


console.log(t1());

export { t2 };



const m = { name: 't2' };


function t2() {
    debugger;
    return m;
}