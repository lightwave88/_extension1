debugger;

import { G } from './g.js';
debugger;

try {
    console.dir(G);    
} catch (error) {
    console.log(error);
}

const a = {
    name: 'a',
    info() {
        debugger;
        console.dir(G);
    }
};

export { a };