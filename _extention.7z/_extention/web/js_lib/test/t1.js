debugger

import { t2 } from './t2.js';

debugger;
export { t1 };

console.log(t2());

debugger;

const m = {
    name:'t1'
}

function t1() {
    debugger;
    return m;
}


