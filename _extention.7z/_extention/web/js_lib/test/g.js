debugger;
const G = {};

debugger;
export { G };