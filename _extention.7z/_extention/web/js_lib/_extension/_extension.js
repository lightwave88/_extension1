!(function () {
    {
        // debugger;

        // debugger;
        // nodejs 需要
        // 延緩載入
        const $importQueue = [];
        const $importModules = [];

        // 一個進程只能對一個 _ 擴增
        // 避免搞得太複雜
        const $extension = {
            'callback_id': 0,
            '_': null,
            '_path': null,
            extensionPath: null,
            system: null,
            isWorkerEnv: false,
        };


        // 新增 _.$mixin() 功能
        // 可進一步控，制有此功能是否要 override
        $importQueue.push(function (_) {
            _.mixin({
                "$mixin": checkmixin
            });
        });


        //--------------------------------------------------------------------------
        // 一個進程只能對一個 _ 擴增
        // 避免搞得太複雜

        // nodejs 對外的接口
        const $nodejs_api = {
            import(callback) {
                // debugger;
                if (typeof callback != 'function') {
                    throw new TypeError('args[0] must be function');
                }
                if ($extension['_'] == null) {
                    $importQueue.unshift(callback);
                } else {
                    let _import = callback($extension['_']);
                    checkmixin(_import);
                }
            },
            // 匯入要擴增的模組
            mixin(map) {
                // debugger;
                // extension 尚未與 _ 有聯係
                if ($extension['_'] == null) {
                    $importModules.unshift(map);
                } else {
                    checkmixin(map);
                }
            },
            // 對 _ 擴充
            expand(moduleName) {
                // debugger;

                let _, _path;
                if (typeof moduleName != 'string') {
                    _ = moduleName;
                } else {
                    _ = require(moduleName);
                }

                if ($extension['_'] == null) {
                    $extension['_'] = _;
                } else {
                    if (!Object.is($extension['_'], _)) {
                        // 只能對一個 _ expand
                        throw new Error(`has expand ${_path} before`);
                    }
                }

                if (_['$$$extension'] != null) {
                    return _;
                }

                let setting = {};

                if (typeof moduleName == 'string') {
                    setting['_path'] = require.resolve(moduleName);
                }
                setting['_'] = _;
                setting.extensionPath = require.resolve('_extension');

                linkExtension(_, setting);

                checkImport(_);

                return _;
            },
            get ['_']() {
                return $extension['_'];
            },
            get extension() {
                return $extension;
            }
        };


        //--------------------------------------------------------------------------
        // 初始化
        (() => {
            // check environment
            if (typeof (module) != 'undefined' && module.exports) {
                // nodejs
                // debugger;

                $extension.system = 'nodejs';
                try {
                    const { isMainThread } = require('worker_threads');
                    if (!isMainThread) {
                        $extension.isWorkerEnv = true;
                    }
                } catch (error) {
                    console.log(error);
                }
                // 曝露接口
                // 曝露接口
                // 曝露接口
                module.exports = $nodejs_api;
                return;
            }
            //------------------
            const $root = checkRoot();
            const setting = {};
            let _;

            if (typeof window != 'undefined' && typeof document != 'undefined') {
                // browser
                _ = $root._;

                setting.system = 'browser';

                getScriptPath(setting);

            } else if (typeof (WorkerGlobalScope) == 'undefined') {
                // web_worker
                _ = $root._;

                setting.system = 'browser';
                setting.isWorkerEnv = true;

            } else {
                throw new Error('no support this system');
            }
            setting['_'] = _;

            linkExtension(_, setting);

            checkImport(_);
        })();
        //------------------------------------------------------------------------------
        function linkExtension(_, setting) {

            if (_ == null) {
                throw new Error('no import _');
            }

            if (_['$$$extension'] != null) {
                return;
            }

            Object.keys(setting).forEach((key) => {
                if (!(key in $extension)) {
                    throw new Error(`no this attr(${key})`);
                }

                $extension[key] = setting[key];
            });


            _['$$$extension'] = $extension;
        }
        //------------------------------------------------------------------------------
        function getScriptPath(options) {
            // debugger;

            if (typeof window == "undefined" || typeof document == "undefined") {
                return;
            }

            let scripts = document.querySelectorAll('script');
            scripts = Array.from(scripts);
            let script = scripts.pop();

            options.extensionPath = script.src;
            // ----------------------------
            // find scriptPath
            let reg = /[^]*(underscore|lodash)[^\///]*$/i;

            while ((script = scripts.pop()) != null) {
                let src = script.src;
                if (src && reg.test(src)) {
                    options['_path'] = src;
                    break;
                }
            }

            scripts = null;
        }
        //------------------------------------------------------------------------------
        function checkImport(_) {
            // debugger;

            while ($importModules.length) {
                let imp = $importModules.pop();
                checkmixin(imp);
            }

            while ($importQueue.length) {
                let callback = $importQueue.pop();
                let imp = callback(_);

                if (imp != null) {
                    checkmixin(imp);
                }
            }
        }
        //------------------------------------------------------------------------------
        function checkmixin(map) {

            const _ = $extension['_'];

            if (_ == null) {
                throw new Error('_ not import yet');
            }

            let keys = Object.keys(map);

            // 檢查是否要 override
            keys.forEach((k) => {
                let value = map[k];
                let override = false;
                let fun;

                if (value != null && typeof value == 'object') {
                    ({ override = false, fun } = value);
                } else {
                    fun = value;
                }

                if (typeof _[k] == 'function' && !override) {
                    // 避免 override
                    delete map[k];
                } else {
                    map[k] = fun;
                }
            });

            _.mixin(map);
        }


        //------------------------------------------------------------------------------
        function checkRoot() {
            let root;

            if (typeof self == 'object' && self.self === self) {
                root = self;
            } else if (typeof global == 'object' && global.global === global) {
                root = global;
            }
            root = root || this;

            return root;
        }

    }
    //==========================================================================
    {
        // basic tool


    }
})();




