!(function () {
    const _ = (() => {
        // debugger;
        // nodejs 需要
        // 延緩載入
        const $importQueue = [];

        // 一個進程只能對一個 _ 擴增
        // 避免搞得太複雜
        const $extension = {
            "callback_id": 0,
            "_": null,
            env: {
                '_path': null,
                extensionPath: null,
                // browser|nodejs
                system: null,
                isWorkerEnv: false,
            },
        };


        // 新增 _.$mixin() 功能
        // 可進一步控，制有此功能是否要 override
        $importQueue.push(function (_) {
            _.mixin({
                "$mixin": checkmixin
            });
        });
        //----------------------------------------------------------------------
        // 一個進程只能對一個 _ 擴增
        // 避免搞得太複雜

        // nodejs 對外的接口
        const $nodejs_api = {
            importModule(callback) {

                // debugger;
                if (typeof callback != 'function') {
                    throw new TypeError('importModule args[0] must be function');
                }
                if ($extension._ == null) {
                    $importQueue.unshift(callback);
                } else {
                    let _import = callback(env._);
                    checkmixin(_import);
                }
            },
            // API 對 _ 擴充
            expand(moduleName) {
                // debugger;
                let _;
                if (typeof moduleName != 'string') {
                    _ = moduleName;
                } else {
                    _ = require(moduleName);
                }

                let env_set = {};

                if (typeof moduleName == 'string') {
                    env_set['_path'] = require.resolve(moduleName);
                }

                env_set.extensionPath = require.resolve('_extension');

                if ($extension._ == null) {
                    $extension._ = _;
                } else {
                    if (!Object.is($extension._, _)) {
                        // 只能對一個 _ expand
                        throw new Error(`has expand ${env_set['_path']} before`);
                    }
                }

                if (_['$$$extension'] != null) {
                    return _;
                }

                link(_);

                setEnv(_, env_set);

                checkImport(_);

                return _;
            },
            getSource() {
                return $extension._;
            },
            getExtension() {
                return $extension;
            }
        };
        //----------------------------------------------------------------------

        function setEnv(_, setting) {

            const extension = _['$$$extension'];
            const env = extension.env;

            Object.keys(setting).forEach((key) => {
                if (!(key in env)) {
                    throw new Error(`no this attr(${key})`);
                }

                env[key] = setting[key];
            });
        }
        //----------------------------------------------------------------------
        function checkImport(_) {
            // debugger;            

            while ($importQueue.length) {
                let callback = $importQueue.pop();

                // 注入函式
                let imp = callback(_);

                if (imp != null) {
                    checkmixin(imp);
                }
            }
        }
        //----------------------------------------------------------------------
        function checkmixin(map) {

            const _ = $extension._;

            if (_ == null) {
                throw new Error('_ not import yet');
            }

            let keys = Object.keys(map);

            // 檢查是否要 override
            keys.forEach((k) => {
                let value = map[k];
                let override = false;
                let fun;

                if (value != null && typeof value == 'object') {
                    ({override = false, fun} = value);
                } else {
                    fun = value;
                }

                if (typeof _[k] == 'function' && !override) {
                    // 避免 override
                    delete map[k];
                } else {
                    map[k] = fun;
                }
            });

            _.mixin(map);
        }
        //----------------------------------------------------------------------
        function is_enjected(_) {
            if (_['$$$extension'] == null) {

                $extension._ = _;
                _['$$$extension'] = $extension;

                return false;
            } else {
                if (!Object.is($extension._, _)) {
                    // 只能對一個 _ expand
                    throw new Error(`has expand ${env_set['_path']} before`);
                }

                if (!Object.is($extension, ['$$$extension'])) {
                    throw new Error(`_.$$$extension has assign`);
                }
                return true;
            }
        }
        //----------------------------------------------------------------------
        function checkRoot() {
            let root;

            if (typeof self == 'object' && self.self === self) {
                root = self;
            } else if (typeof global == 'object' && global.global === global) {
                root = global;
            }
            root = root || this;

            return root;
        }
        //----------------------------------------------------------------------
        // 初始化
        {
            // debugger;

            // check environment
            if (typeof (module) != 'undefined' && module.exports) {
                // nodejs
                // debugger;

                const env = $extension.env;

                env.system = 'nodejs';
                try {
                    const {isMainThread} = require('worker_threads');
                    if (!isMainThread) {
                        env.isWorkerEnv = true;
                    }
                } catch (error) {
                    console.log(error);
                }

                // 曝露接口
                module.exports = $nodejs_api;
                return;
            }
            //------------------
            const $root = checkRoot();
            const env_set = {};
            let _;

            if (typeof window != 'undefined' && typeof document != 'undefined') {
                // browser
                _ = $root._;

                env_set.system = 'browser';

            } else if (typeof (WorkerGlobalScope) != 'undefined') {
                // web_worker
                _ = $root._;

                env_set.system = 'browser';
                env_set.isWorkerEnv = true;

            } else {
                throw new Error('no support this system');
            }

            if (is_enjected(_)) {
                return;
            }

            setEnv(_, env_set);

            checkImport(_);
        }

        return $extension._;
    })();
    //==========================================================================
    // debugger;
    (() => {
        // basic tool


        const $injectModules = {};

        {
            // isPlainObject
            $injectModules['isPlainObject'] = {
                override: false,
                fun: isPlainObject
            };

            function isPlainObject(obj) {

                if (typeof obj != "object") {
                    return false;
                }

                if (obj == null) {
                    return false;
                }

                let res = Object.prototype.toString.call(obj);

                if (!/^\[object Object\]$/.test(res)) {
                    return false;
                }

                if (obj.constructor !== {}.constructor) {
                    return false;
                }

                return true;
            }
        }
        //==========================================================================

        {
            // getClassName

            $injectModules['getClassName'] = {
                override: false,
                fun: getClassName
            };

            function getClassName(data) {
                let _toString = Object.prototype.toString;

                let type = typeof (data);

                if (/object/.test(type)) {

                    if (data === null) {
                        type = "null";
                    } else {
                        type = _toString.call(data);

                        let res = /\[\w+\s+(\w+)\]/.exec(type);
                        if (res && res[1]) {
                            type = res[1];
                        }
                    }
                }
                return type;
            }
        }
        //==========================================================================
        {
            // job: [function|promise]
            $injectModules['timeout'] = {
                override: false,
                fun: timeout
            };


            function timeout(job, timeLimit, context) {
                let p1;

                if (typeof timeLimit != 'number') {
                    throw new TypeError("timeout arg[1] must be number");
                }

                if (typeof (job) == "function") {

                    if (context != null) {
                        job = job.bind(context);
                    }
                    p1 = new Promise(job);
                } else if (job instanceof Promise) {
                    p1 = job;
                } else {
                    throw new TypeError("timeout arg[0] must be promise or function");
                }
                //-----------------------
                let _res;
                let _rej;

                let r_p = new Promise(function (res, rej) {

                    _res = res;
                    _rej = rej;
                });
                //-----------------------
                // 計時器
                let timeHandle = setTimeout(() => {
                    _rej(new Error('timeout'));
                }, timeLimit);


                p1.then((data) => {

                    clearTimeout(timeHandle);
                    timeHandle = null;
                    _res(data);
                }, (err) => {
                    clearTimeout(timeHandle);
                    timeHandle = null;
                    _rej(err);
                });
                //-----------------------

                return r_p;
            }
        }
        //==========================================================================
        {

            // promise
            //
            // callback: [function(返回 promise)|promise[]]
            // context: 背後執行對象
            $injectModules['promise'] = {
                override: true,
                fun: _promise
            };

            class Pr extends Promise {
                constructor(executor) {
                    debugger;

                    super((resolve, reject) => {
                        return executor(resolve, reject);
                    });
                }

                always(callback) {
                    debugger;
                    const p = super.then((d) => {
                        debugger;
                        return callback(null, d);
                    }, (er) => {
                        debugger;
                        return callback(er);
                    });
                    // 反囘原有的 promise
                    return p;
                }
            }

            function _promise(callback, context) {
                let p;

                if (callback instanceof Promise) {
                    p = Pr.resolve(callback);
                } else if (typeof (callback) == "function") {

                    (callback == null) || (callback.bind(context));

                    p = new Pr(callback);
                } else if (Array.isArray(callback)) {

                    if (context != null) {
                        callback = callback.map(function (fn) {
                            return fn.bind(context);
                        });
                    }
                    p = Pr.all(callback);
                }
                //-----------------------
                return p;
            }

            _promise.resolve = function (d) {
                return Pr.resolve(d);
            }

            _promise.reject = function (er) {
                return Pr.reject(er);
            }
        }
        //==========================================================================
        {
            // deferred
            class Deferred extends Promise {

                constructor(executor) {
                    //debugger;
                    let res;
                    let rej;

                    super((resolve, reject) => {
                        //debugger;

                        if (typeof executor != 'function') {
                            res = resolve;
                            rej = reject;
                            executor = function () {
                                //debugger;
                            };
                        }
                        return executor(resolve, reject);
                    });
                    //debugger;
                    if (res != null) {
                        this.resolve = function (d) {
                            res(d);
                        }
                    }

                    if (rej != null) {
                        this.reject = function (er) {
                            rej(er);
                        };
                    }
                }

                always(callback) {
                    const p = super.then((d) => {
                        //debugger;
                        return callback(null, d);
                    }, (er) => {
                        //debugger;
                        return callback(er);
                    });
                    return p;
                }
            }


            $injectModules['deferred'] = {
                override: false,
                fun() {
                    return new Deferred();
                }
            };
        }
        //======================================================================
        // debugger;
        _.$mixin($injectModules);
    })();

})();




