import { $GM } from './globalModule.js';


// 取得系統資訊
// 每個進程只有一個
class SystemInfo {
    static getInstance() {
        return new SystemInfo();
    }

    constructor() {
        // debugger;

        // 初始化的時候 _ 尚未 import
        this.$info = {
            system: null,
            workerPath: null,
            "_path": null,
            extensionPath: null,
            "_": null,
        };

        this._init();
    }

    _init() {
        debugger;
        const info = this.$info;

        let _;

        try {
            // nodejs
            let ex_module = require('_extension');
            _ = ex_module['_'];

            info.workerPath = require.resolve('./worker.js');

        } catch (error) {
            // browser
            let root = this._checkRoot();
            _ = root['_'];
        }
        //------------------

        if (_ == null) {
            throw new Error('no import _');
        }

        const $extension = _['$$$extension'];

        if ($extension == null) {
            throw new Error('no import _extension');
        }

        info['_'] = _;
        // info['_path'] = $extension['_path'];
        // info.extensionPath = $extension.extensionPath || null;
        info.system = $extension.system;
    }

    _checkRoot() {
        let root;

        if (typeof self == 'object' && self.self === self) {
            root = self;
        } else if (typeof global == 'object' && global.global === global) {
            root = global;
        }
        root = root || this;

        return root;
    }

    get(key) {
        const info = Object.assign({}, this.$info);

        if (key == null) {
            return info;
        }

        return (info[key] || null);
    }
}

const systemInfo = SystemInfo.getInstance();

export default systemInfo;