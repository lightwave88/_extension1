import $GM from './globalModule.js';

// 取得系統資訊
// 每個進程只有一個
class SystemInfo {
    static getInstance() {
        return new SystemInfo();
    }
    //--------------------------------------------------------------------------
    constructor() {
        // debugger;

        // 初始化的時候 _ 尚未 import
        this._ = null;
        this.extension = null;
        this.isWorkerEnv = null;
    }
    //--------------------------------------------------------------------------
    check() {
        const $error = $GM.get('error');
        const EnvError = $error['env_error'];

        const info = this.$info;

        let _;

        try {
            // nodejs
            let ex_module = require('_extension');
            _ = ex_module.getSource();
        } catch (error) {
            // browser
            let root = this._checkRoot();

            if (root != null && typeof root == 'object') {
                _ = root._;
            }
        }
        //------------------
        if (_ == null) {
            throw new Error('no import _');
        }

        this._ = _;

        $GM.set('_', _);

        const $extension = _['$$$extension'];

        if ($extension == null) {
            throw new Error('no import _extension');
        }
        this.extension = $extension;

        if (!/^browser$/.test($extension.env.system)) {
            throw new EnvError('_.workerPool() must use in browser env');
        }

        this.isWorkerEnv = $extension.env.isWorkerEnv;
        if (this.isWorkerEnv) {
            throw new EnvError('_.workerPool() cant run in worker env');
        }
    }
    //--------------------------------------------------------------------------
    _checkRoot() {
        let root;

        if (typeof self == 'object' && self.self === self) {
            root = self;
        } else if (typeof global == 'object' && global.global === global) {
            root = global;
        }
        root = root || this;

        return root;
    }
}

export default SystemInfo;