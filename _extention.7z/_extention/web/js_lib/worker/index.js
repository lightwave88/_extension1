// 載入所需的模組
import $GM from './globalModule.js';

(() => {
    // 注入 _

    if (typeof document == 'undefined' || !document) {
        // 只能在瀏覽器環境執行
        return;
    }

    const $erorr = $GM.get('error');
    //------------------
    // 模組初始化
    let systemInfo = $GM.get('systemInfo');
    systemInfo = systemInfo.getInstance();

    try {
        systemInfo.check();
    } catch (er) {
        if (er instanceof $error['env_error']) {
            return;
        }
        throw er;
    }

    $GM.get('systemInfo', systemInfo);
    //------------------
    const _ = $GM.get('_');
    const API = $GM.get('api');

    _.$mixin({
        workerPool: {
            fun: API,
            override: true,
        }
    });
})();

