

// 載入所需的次模組
import { $GM } from './globalModule.js';

