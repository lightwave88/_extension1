// 載入所需的模組
import $GM from './globalModule.js';

(() => {
    // 檢查程序

    if (typeof document == 'undefined' || !document) {
        // 只能在瀏覽器環境執行
        return;
    }

    const $erorr = $GM.get('error');
    //------------------
    // 模組初始化
    const $CheckSystem = $GM.get('checkSystem');
    const $checkSystem = $CheckSystem.getInstance();

    try {
        // 檢查系統
        $checkSystem.check();
    } catch (er) {
        if (er instanceof $error['env_error']) {
            // 不對的環境
            console.log(er);
            return;
        }
        throw er;
    }

    const _ = $GM.get('_');

    inject(_);
})();
//-----------------------------------------------------------------------------
// 注入程序
function inject(_) {

    const API = $GM.get('api');

    _.$mixin({
        workerPool: {
            fun: API,
            override: true,
        }
    });
}

