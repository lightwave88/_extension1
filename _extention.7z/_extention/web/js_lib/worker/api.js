
import { $GM } from './globalModule.js';


const get_globalPool = (function () {
    // 封閉的值
    let $globalPool;

    return () => {
        debugger;
        if ($globalPool == null) {
            const $Pool = $GM.get('Pool');
            $globalPool = $Pool.getInstance();
        }
        return $globalPool;
    };

})();

//------------------------------------------------------------------------------
export default API;


// _.worker();
function API(...args) {
    debugger;
    
    const pool = get_globalPool();
    // return pool.execute(args);
}

(function () {

    this.setConfig = function (config) {
        let pool = get_globalPool();
        pool.setConfig(config);
    };
    //------------------
    this.makePool = function () {

    };

    //------------------
    // worker 必須額外載入的 script
    this.setImportScript = function (script) {

    };

}).call(API);

(() => {
    // 注入 _

    if (typeof document == 'undefined' || !document) {
        return;
    }

    const _ = self._;
    if (_ == null) {
        throw new Error('no import _');
    }

    _.mixin({
        worker: API
    });

})();
