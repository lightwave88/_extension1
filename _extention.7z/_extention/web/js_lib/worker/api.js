
import { $GM } from './globalModule.js';


const get_globalPool = function () {       
    const _ = self._;
    const extension = _['$$$extension'];

    if (extension.workerPool == null) {
        const $Pool = $GM.get('Pool');
        extension.workerPool = $Pool.getInstance();
    }
    return extension.workerPool;
};
//------------------------------------------------------------------------------
export default API;

// _.worker();
function API(...args) {
    debugger;

    const pool = get_globalPool();
    pool.init();
    return pool.execute(args);
}
//------------------------------------------------------------------------------
(function () {

    this.setConfig = function (config) {
        const pool = get_globalPool();
        pool.setConfig(config);
        return pool;
    };
    //--------------------------------------------------------------------------
    this.init = function (config) {
        debugger;

        const pool = get_globalPool();

        if (pool.is_inited) {
            return;
        }

        if (config != null) {
            pool.setConfig(config);
        }

        pool.init();
        return pool;
    }

    //--------------------------------------------------------------------------
    // worker 必須額外載入的 script
    this.setWorkerInit = function (...args) {
        debugger;

        const pool = get_globalPool();
        pool.setWorkerInit.apply(pool, args);

        return pool;
    };

    //--------------------------------------------------------------------------
    // 生成一個獨立於全局 pool 的 pool 
    this.makePool = function () {

    };

}).call(API);
//------------------------------------------------------------------------------
(() => {
    // 注入 _

    if (typeof document == 'undefined' || !document) {
        // 只能在瀏覽器環境執行
        return;
    }
    const _ = self._;
    if (_ == null) {
        throw new Error('no import _');
    }
    _.mixin({
        worker: API
    });
})();
