import $GM from './globalModule.js';

const get_globalPool = function () {
    const _ = $GM.get('_');
    const extension = _['$$$extension'];

    if (extension['global_workerPool'] == null) {
        const $Pool = $GM.get('Pool');
        extension['global_workerPool'] = $Pool.getInstance();
    }
    return extension['global_workerPool'];
};
//------------------------------------------------------------------------------
// _.worker();
function API(...args) {
    // API 精簡化
    return API.execute.apply(API, args);

}

export default API;
//------------------------------------------------------------------------------
(function () {

    Object.defineProperty(API, 'config', {
        enumerable: true,
        configurable: true,
        get: function () {
            debugger;

            const pool = get_globalPool();
            return pool.config;
        }
    });

    this.execute = function (args) {
        debugger;
        const pool = get_globalPool();
        return pool.execute(args);
    };

    this.close = function () {
        const pool = get_globalPool();
        pool.close();
    };

    //--------------------------------------------------------------------------
    this.start = function (config) {
        debugger;

        const pool = get_globalPool();

        if (pool.is_inited) {
            return pool;
        }

        if (config != null) {
            pool.setConfig(config);
        }

        pool.start();
        return pool;
    }

    this.importScripts = function (script) {
        const pool = get_globalPool();
        pool.importScripts(script);
    }
    //--------------------------------------------------------------------------
    this.setConfig = function (config) {
        const pool = get_globalPool();
        pool.setConfig(config);
        return pool;
    };


    //--------------------------------------------------------------------------
    // worker 必須額外載入的 script
    this.setWorkerInit = function (...args) {
        debugger;

        const pool = get_globalPool();
        pool.setWorkerInit.apply(pool, args);

        return pool;
    };

    //--------------------------------------------------------------------------
    // 生成一個獨立於全局 pool 的 pool 
    this.makePool = function (config) {

    };


    // 形成一個 job
    this.job = function (...args) {
        const Job_class = $GM.get('Job');
        const job = Job_class.getInstance(args);
        return job;
    };
}).call(API);

