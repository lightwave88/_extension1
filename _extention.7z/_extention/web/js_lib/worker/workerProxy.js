import WorkerProxy_abs from './workerProxy_abs.js';
import $GM from './globalModule.js'

        class WorkerProxy extends WorkerProxy_abs {
    static getInstance(pool) {
        return new WorkerProxy(pool);
    }
    //--------------------------------------------------------------------------
    // 實作 worker 的建立
    initialization() {
        debugger;

        let workerContent = getWorkerContent(this);

        this.$worker = new Worker(workerContent);

        this.$worker.addEventListener('message', this.$event_end);
        this.$worker.addEventListener('error', this.$event_error);
    }
    //--------------------------------------------------------------------------
    postMessage(msg) {
        try {
            // 對訊息的合法性做檢查
            msg = JSON.stringify(msg);
        } catch (er) {
            throw new TypeError(`postMsg can't pass throught JSON.stringify()`);
        }

        this.$worker.postMessage(msg);
    }
    //--------------------------------------------------------------------------
    // 實作 closeWorker
    terminate() {
        const w = this.$worker;
        this.$worker = undefined;

        w.removeEventListener('message', this.$event_end);
        w.removeEventListener('error', this.$event_error);

        w.terminate();
    }
    //--------------------------------------------------------------------------
    // 事件 callback
    getEndEvent() {
        return (e) => {
            debugger;
            const data = e.data;

            console.dir(data);

            let is_sysMsg;

            try {
                is_sysMsg = (this.$id_2 in data);
            } catch (error) {
            }


            if (is_sysMsg) {

                let {msg, status} = data;
                // 系統預設事件
                switch (status) {
                    case 'initialized':
                        this.initinated();
                        break;
                    case 'jobError':
                        // 捕捉到的 error
                        this.jobError(msg);
                        break;
                    case 'jobEnd':
                        this.jobEnd(msg);
                        break;
                    default:
                        throw new Error('no status report');
                        break;
                }
            } else {
                // 使用者發射的事件
                this.$job.recieveMsg(data);
            }
        };
    }

    // worker 執行錯誤
    getErrorEvent() {
        return (err) => {
            debugger;

            // 沒補抓到的 error
            this.workerError(err);
        };
    }
}

export default WorkerProxy;

////////////////////////////////////////////////////////////////////////////////
// 取得 worker 的内文
function getWorkerContent(w) {
    // debugger;

    let content = '';
    //------------------
    let fn_content_1 = 'null';

    if (w.$pool.$worker_init.callback != null) {
        fn_content_1 = w.$pool.$worker_init.callback;
    }
    let fn_content_2 = workerContent_2();

    let init_args = w.$pool.$worker_init.args || [];
    init_args = JSON.stringify(init_args);

    let workerID_1 = JSON.stringify(w.$id_1);
    let workerID_2 = JSON.stringify(w.$id_2);

    let scriptList = w.$pool.$importScripts;
    scriptList = JSON.stringify(scriptList);

    //------------------
    content = `
    debugger;

    let $$$workerID_1 = ${workerID_1};
    let $$$workerID_2 = ${workerID_2};
    //------------------
    // import scripts
    let $$$scriptList = ${scriptList};

    $$$scriptList.forEach(function (scriptPath) {
        try {
            importScripts(scriptPath);
        } catch (error) {
            throw new Error('script(' + scriptPath + ')  load error');
        }
    });
    //------------------
    debugger;

    const $$$worker = (${fn_content_2})();

    debugger;

    let $$$init_fun = ${fn_content_1};

    if(typeof $$$init_fun == 'function'){
        $$$init_fun.apply(self, ${init_args});
    }
    
    debugger;

    // 初始化
    $$$worker.init(self, $$$workerID_1, $$$workerID_2);

    $$$scriptList = null;
    $$$init_fun = null;
    $$$workerID_1 = null;
    $$$workerID_2 = null;`;
    //------------------
    console.log(content);

    let bb = new Blob([content]);

    return URL.createObjectURL(bb);
}
////////////////////////////////////////////////////////////////////////////////

function workerContent_2() {
    const $fun = function () {
        // worker 内文

        const $worker = {
            "$id_1": null,
            "$id_2": null,
            runtimeEnv: null,
            // 使用者注冊的
            listenerList: [],
            global: null,
            'proxy_self': null,
            // job 中讓使用者操作的 handle
            'cmd_handle': null,
            init(global, id_1, id_2) {
                debugger;

                this.global = global;
                this.$id_1 = id_1;
                this.$id_2 = id_2;

                if (this.$id_1 == null || this.$id_2 == null) {
                    throw new Error('no get $$$worker_id');
                }
                //------------------
                this.global.addEventListener('message', (e) => {
                    debugger;

                    let data = e.data;

                    try {
                        data = JSON.parse(data);
                    } catch (error) {
                        this.postRunTimeError(er);
                        return;
                    }

                    let judge_1;

                    try {
                        judge_1 = (this.$id_2 in data);
                    } catch (error) {
                    }

                    if (judge_1) {
                        // 來自系統的訊息

                        const cmd = data.cmd;

                        switch (cmd) {
                            case 'job':
                            default:
                                try {
                                    // 執行任務
                                    this.doJob(data.job);
                                } catch (er) {
                                    debugger;
                                    // 執行錯誤
                                    this.postRunTimeError(er);
                                }
                                break;
                        }

                    } else {
                        // 來自使用者發的訊息
                        this.callListener(data);
                    }
                });
                //------------------
                this.postSysMsg('initialized');
            },
            // 當使用者發射訊號
            // 會呼叫使用者
            callListener(msg) {
                this.listenerList.forEach((callback) => {
                    callback(msg);
                });
            },
            // 發送系統訊息用
            postSysMsg(status, msg) {

                const report = {
                    // 系統訊息的憑證                    
                    status: status
                };

                if (typeof msg == 'object' && !(msg instanceof Error)) {
                    Object.assign(report, msg);
                } else {
                    report.msg = msg;
                }

                switch (status) {
                    // jobEnd
                    case 'jobError':
                    case 'jobEnd':
                        // 清除使用者設定的監聽事件
                        this.listenerList.length = 0;
                        break;
                    default:
                        break;
                }

                report[this.$id_2] = true;

                this.postMsg(report);
            },
            // 發送訊息
            postMsg(msg) {
                this.global.postMessage(msg);
            },
            postRunTimeError(er) {
                // job 執行錯誤                
                this.postSysMsg('jobError', er);
            },
            getProxySelf() {

                if (this['proxy_self'] != null) {
                    return this['proxy_self'];
                }
                //-----------------
                // 遮蔽 self 部分功能
                let s = new Proxy(this.global, {
                    get(t, k) {
                        let res;
                        switch (k) {
                            case 'addEventListener':
                                res = function () { };
                                break;
                            default:
                                res = t[k];
                                break;
                        }
                        return res;
                    },
                    set(t, k, v) {
                        switch (k) {
                            case 'onmessage':
                                break;
                            default:
                                t[k] = v;
                                break;
                        }
                        return true;
                    }
                });

                this['proxy_self'] = s;

                return s;
            },
            buildFun(funText) {
                let fun = new Function('self', `
                    'use strict';
                    
                    // 遮蔽以下的功能
                    const addEventListener = function(...args){};
                    const onmessage = {};
                
                return (${funText});`);

                const proxy_self = this.getProxySelf();
                fun = fun(proxy_self);

                return fun;
            },
            getCommand() {
                if (this['cmd_handle'] != null) {
                    return this['cmd_handle'];
                }
                const $this = this;

                const command = {
                    resolve(data) {
                        $this.postSysMsg('jobEnd', data);
                    },
                    reject(er) {
                        $this.postSysMsg('jobError', er);
                    },
                    onMsg(callback) {
                        $this.listenerList.push(callback);
                    },
                    postMsg(msg) {
                        $this.postMsg(msg);
                    },
                };
                this['cmd_handle'] = command;

                return command;
            },
            // 建造一個乾淨的執行環境
            getRuntimeEnv() {
                if (this.runtimeEnv != null) {
                    return this.runtimeEnv;
                }

                let fun_content = `
                    'use strict';
                    return fun.apply(context, args);
                `;

                this.runtimeEnv = new Function('fun', 'context', 'args', fun_content);

                return this.runtimeEnv;
            },
            _checkArgs_1(args, funList, context) {
                funList.forEach((index) => {
                    let fn_content = args[index];
                    let fn = this.buildFun(fn_content);
                    args[index] = fn.bind(context);
                });
            },
            _checkArgs_2(args, funList) {
                if (funList.length) {
                    throw new TypeError(`args can't include function`);
                }
            },
            // 執行任務
            doJob(jobData) {
                debugger;

                let {
                    // _命令
                    cmd = null,
                    act = null,
                    args = [],
                    funList = [],
                    id,
                } = jobData;

                let job;
                let context = null;
                let $_;

                if (cmd != null) {
                    context = _;

                    if (this.global._ == null) {
                        throw new Error('_ no import');
                    }
                    $_ = this.global._;

                    job = $_[cmd];

                    if (job == null) {
                        throw new Error(`no this function _.(${cmd})`);
                    }

                    this._checkArgs_1(args, funList, context);
                } else {
                    job = this.buildFun(act);

                    this._checkArgs_2(args, funList);
                    // 插入一個可讓使用者執行命令的 handle
                    args.unshift(this.getCommand());
                }
                debugger;
                // 建立一個乾淨的執行環境
                const env = this.getRuntimeEnv();

                // 執行任務
                env(job, context, args);

            },

        };
        //------------------
        return $worker;
    }; // fun end

    return Function.prototype.toString.call($fun);
}