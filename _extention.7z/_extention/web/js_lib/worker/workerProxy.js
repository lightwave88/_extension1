
import WorkerProxy_abs from './workerProxy_abs.js';
import { $GM } from './globalModule.js'

class WorkerProxy extends WorkerProxy_abs {
    static getInstance(pool) {
        return new WorkerProxy(pool);
    }
    //--------------------------------------------------------------------------
    // 實作 worker 的建立
    initialization() {
        debugger;

        let workerContent = getWorkerContent(this);

        this.$worker = new Worker(workerContent);

        this.$worker.addEventListener('message', this.$event_end);
        this.$worker.addEventListener('error', this.$event_error);
    }
    //--------------------------------------------------------------------------
    // 實作終結 worker
    terminate() {
        debugger;

        const w = this.$worker;
        this.$worker = undefined;

        w.removeEventListener('message', this.$event_end);
        w.removeEventListener('error', this.$event_error);

        w.terminate();
    }
    //--------------------------------------------------------------------------
    // 事件 callback
    getEndEvent() {
        return (e) => {
            debugger;
            const data = e.data;
            let { res, status } = data;

            switch (status) {
                case 'initialized':
                    this.initinated();
                    break;
                case 'error':
                    // 捕捉到的 error
                    this.jobError(res);
                    break;
                default:
                    this.jobEnd(res);
                    break;
            }
        };
    }

    // 事件 callback
    getErrorEvent() {
        return (err) => {
            debugger;

            // 沒補抓到的 error
            this.jobError(err);
        };
    }
}

export default WorkerProxy;

//------------------------------------------------------------------------------
// 取得 worker 的内文
function getWorkerContent(w) {
    // debugger;

    let content = '';

    let fn_content_1 = '';

    if (w.$pool.$worker_init.callback != null) {
        let init_args = w.$pool.$worker_init.args || [];
        init_args = JSON.stringify(init_args);
        fn_content_1 = `(${w.$pool.$worker_init.callback}).apply(self, ${init_args});`
    }

    let fn_content_2 = workerContent_2();

    let scriptList = w.$pool.$importScripts;
    scriptList = JSON.stringify(scriptList);

    //------------------

    content = `
    debugger;

    const $worker_id = ${w.$id};
    let $scriptList = ${scriptList};

    $scriptList.forEach(function (scriptPath) {
        try {
            importScripts(scriptPath);
        } catch (error) {
            throw new Error('script(' + scriptPath + ')  load error');
        }
    });

    $scriptList = null;

    ${fn_content_1}
    
    (${fn_content_2})();`;


    console.log(content);
    //-----------------------
    let bb = new Blob([content]);

    return URL.createObjectURL(bb);
}
//------------------------------------------------------------------------------
// worker 的内容
function workerContent_2() {
    let $fn_content;
    //------------------

    const $content = function () {
        debugger;        

        
        self.addEventListener('message', function (e) {
            debugger;

            let data = e.data || {};
            doWork(data);
        });

        // 通知已初始化完畢
        post_msg(null, 'initialized');

        //------------------------------------------------

        function doWork(data) {
            debugger;
            let {
                // _命令
                command = null,
                action = null,
                args,
                funList,
                id
            } = data;

            // 參數
            args = args || [];
            funList = funList || [];

            let fn;
            let context;
            if (command != null) {

                if (self._ == null) {
                    throw new Error('_ no import');
                }

                fn = self._[command];

                if (fn == null) {
                    throw new Error(`no this function _.(${command})`);
                }

                context = _;
            } else {
                fn = buildFun(action);
            }

            // debugger;
            // _ 的運算
            let res = fn.apply(context, args);
            //----------------------------
            if (res instanceof Promise) {
                res.then(function () {
                    post_msg(res, true);
                });

                res.catch(function (e) {
                    let err;

                    if (!(e instanceof Error)) {
                        err = new Error(e);
                    }
                    throw err;
                });

            } else {
                post_msg(res);
            }


        }
        //----------------------------
        function post_msg(res, status = 'ok') {

            if (true) {
                setTimeout(() => {

                    self.postMessage({
                        res: res,
                        status
                    });
                }, 1000);
            } else {

                self.postMessage({
                    res: res
                });
            }
        }
        //----------------------------
        function post_error(err) {

        }
        //------------------------------------------------

        function buildFun(content) {
            debugger;
            let fun = new Function(`return (${content});`);

            return fun();
        }
    };
    //------------------
    return (function () {
        // debugger;
        if ($fn_content == null) {
            $fn_content = Function.prototype.toString.call($content);
        }
        return $fn_content;
    })();

}

