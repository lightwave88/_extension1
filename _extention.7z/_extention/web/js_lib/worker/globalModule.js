// debugger;

const GModule = new Map();
export { GModule as $GM };

//------------------
// debugger;

import systemInfo from './systemInfo.js';
GModule.set('systemInfo', systemInfo);

import Config from './config.js';
GModule.set('Config', Config);

import Pool from './workerPool.js';
GModule.set('Pool', Pool);

import API from './api.js';
GModule.set('API', API);
