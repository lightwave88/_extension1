// debugger;

const GModule = new Map();
export { GModule as $GM };

//------------------
// debugger;

import systemInfo from './systemInfo.js';
GModule.set('systemInfo', systemInfo);

import Config from './config.js';
GModule.set('Config', Config);

import Job from './job.js';
GModule.set('Job', Job);

import WorkerProxy from './workerProxy.js';
GModule.set('WorkerProxy', WorkerProxy);

import Pool from './workerPool.js';
GModule.set('Pool', Pool);

import API from './api.js';
GModule.set('API', API);
