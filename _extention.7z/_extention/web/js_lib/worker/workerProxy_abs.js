import $GM from './globalModule.js';

// 抽象類
class WorkerProxy_abs {

    static WORKER_UID = 0;

    static getInstance(pool) {
        throw new Error('need override');
    }
    //--------------------------------------------------------------------------
    // employment: 是否是僱員
    constructor(pool) {
        // debugger;

        this.$fn = WorkerProxy_abs;

        this.$pool = pool;

        this.$config = this.$pool.$config;

        this.$timeout = null;

        // 任務超時計時器
        this.$timeout_handle = null;
        //------------------
        this.$id_1 = null;

        this.$id_2 = null;

        // 當前接的任務
        this.$job = null;

        // worker 本體
        this.$worker;

        //------------------
        // 旗標訊號
        this.$flag = {
            busy: false,
            initinated: false
        };

        //------------------
        //callback
        this.$event_end;

        // callback
        this.$event_error;
        //------------------       

        this._init();
    }
    //--------------------------------------------------------------------------
    _init() {
        // debugger;

        this.$id_1 = `W-(${WorkerProxy_abs.WORKER_UID++})`;
        this.$id_2 = (new Date()).getTime();
        this.$id_2 %= 100000;
        this.$id_2 = String(this.$id_2);

        const $config = this.$config;

        if ($config.timeout != null) {
            // 確定是否有執行的時限
            this.$timeout = $config.timeout;
        }

        this.$event_end = this.getEndEvent();
        this.$event_error = this.getErrorEvent();

        this.initialization();
    }
    //--------------------------------------------------------------------------
    // @override
    // 取得本體內容
    // 實例化本體
    // 連接事件
    // 不同系統，有不同的方式
    initialization() {
        throw new Error('need override initialization()');

    }
    //--------------------------------------------------------------------------
    // @override
    // 不同系統，有不同的方式
    postMessage(msg) {
        throw new Error('need override postMessage()');
    }
    //--------------------------------------------------------------------------

    // @override
    // 關閉 worker
    // 不同系統，有不同的方式
    terminate() {
        throw new Error('need override terminate()');
    }
    //--------------------------------------------------------------------------
    // 執行任務
    takeJob(job) {
        debugger;

        console.log('worker(%s)接工作', this.$id);
        this.$flag.busy = true;

        this.$job = job.$$$core;
        // debugger;

        this.$job.setWorker(this);
        // 取得任務內容
        let jobContent = this.$job.getJobContent();

        let msg = this._setMsg({
            cmd: 'job',
            job: jobContent
        });

        // 請 worker 工作
        this.postMessage(msg);

        // 若工作有時限
        if (this.$timeout != null) {
            this.$timeout_handle = setTimeout(() => {
                this.jobTimeout();
            }, this.$timeout);
        }
    }

    //--------------------------------------------------------------------------
    // 離職
    dismiss(report = true) {
        console.log('worker(%s)離職', this.$id);

        if (!this.$pool.$workers.has(this)) {
            return;
        }

        this.$pool.$workers.delete(this);

        this.terminate();

        if (!report) {
            return;
        }
        // 回報
        this.next();
    }
    //--------------------------------------------------------------------------
    // 初始化完成
    initinated() {
        debugger;

        this.$flag.initinated = true;

        // 通知 pool
        this.next(this);
    }
    //--------------------------------------------------------------------------
    // 工作結束
    jobEnd(res) {
        debugger;

        console.log("worker(%s)任務結束", this.$id);

        const job = this.$job;

        // 通知 pool
        this.next(this);

        job.resolve(res);
    }
    //--------------------------------------------------------------------------
    // 提交的工作發生錯誤
    jobError(err) {
        debugger;

        console.log("worker(%s)任務發生錯誤", this.$id);

        const job = this.$job;

        // 通知 pool
        this.next(this);

        job.reject(err);
    }
    //--------------------------------------------------------------------------
    // 工作超時
    jobTimeout() {
        debugger;
        console.log("worker(%s)任務過時", this.$id);

        const job = this.$job;

        // 離職
        this.dismiss();

        job.reject('time out');
    }

    //--------------------------------------------------------------------------
    // worker 運行錯誤
    workerError(e) {

        if (this.$job) {
            this.$job.reject('worker error');
        }

        this.$pool.workerError(this, e);
    }
    //--------------------------------------------------------------------------
    // 使用者正常中斷工作
    user_stopJop() {

        this.$job.resolve();

        // 離職
        this.dismiss();
    }
    //--------------------------------------------------------------------------
    // 繼續下一步
    next(worker) {
        this.$flag.busy = false;
        this.$job = null;
        this.$pool.noticeByWorker(worker);
    }
    //--------------------------------------------------------------------------
    // @override
    getEndEvent() {
        throw new Error('need override _event_getEndEvent');
    }
    //--------------------------------------------------------------------------
    // @override
    getErrorEvent() {
        throw new Error('need override _event_getErrorEvent');
    }
    //--------------------------------------------------------------------------
    _setMsg(setting) {
        // id: 以供辨認是否是系統訊息                      
        let msg = {
            cmd: null,
        };

        // 寫入標識碼        
        msg[this.$id_2] = true;

        Object.assign(msg, setting);
        return msg;
    }
}

export default WorkerProxy_abs;
