import { $GM } from './globalModule.js';

let WORKER_UID = 0;

// 抽象類
class WorkerProxy_abs {

    static getInstance(pool) {
        throw new Error('need override');
    }

    // employment: 是否是僱員
    constructor(pool) {
        // debugger;

        this.$pool = pool;

        this.$config = this.$pool.$config;       

        this.$timeout = null;

        this.$timeout_handle = null;
        //------------------
        this.$id = WORKER_UID++;

        // 當前接的任務
        this.$job = null;

        // worker 本體
        this.$worker;

        //------------------
        // 旗標訊號
        this.$flag = {
            busy: false,
            initinated: false
        };

        //------------------
        //callback
        this.$event_end;

        // callback
        this.$event_error;
        //------------------

        this._init();
    }
    //--------------------------------------------------------------------------
    _init() {
        // debugger;
        const $config = this.$config;

        if ($config.timeout != null) {
            // 確定是否有執行的時限
            this.$timeout = $config.timeout;
        }        

        this.$event_end = this.getEndEvent();
        this.$event_error = this.getErrorEvent();

        this.initialization();
    }
    //--------------------------------------------------------------------------
    // @override
    // 取得本體內容
    // 實例化本體
    // 連接事件
    initialization() {
        throw new Error('need override initialization()');

    }
    //--------------------------------------------------------------------------
    // @override
    // 關閉 worker
    terminate() {
        throw new Error('need override terminate()');
    }
    //--------------------------------------------------------------------------
    // 執行任務
    takeJob(job) {
        debugger;

        console.log('worker(%s)接工作', this.$id);
        this.$flag.busy = true;

        this.$job = job;
        // debugger;

        // 取得任務內容
        let command = this.$job.getCommand(this);

        // 請 worker 工作
        this.$worker.postMessage(command);

        // 若工作有時限
        if (this.$timeout != null) {
            this.$timeout_handle = setTimeout(() => {
                this.jobTimeout();
            }, this.$timeout);
        }
    }
    //--------------------------------------------------------------------------
    // 初始化完成
    initinated() {
        debugger;

        this.$flag.initinated = true;

        // 通知 pool
        this.$pool.noticeByWorker(this);
    }
    //--------------------------------------------------------------------------
    // 工作結束
    jobEnd(res) {
        debugger;

        this.$flag.busy = false;

        console.log("worker(%s)任務結束", this.$id);


        this.$job.resolve(res);

        this.$job = null;

        setTimeout(() => {
            debugger;
            // 通知 pool
            this.$pool.noticeByWorker(this);
        }, 0);
    }
    //--------------------------------------------------------------------------
    // 工作錯誤
    jobError(err) {
        debugger;

        console.log("worker(%s)任務發生錯誤", this.$id);

        if (!this.$flag.initinated) {
            // 初始化失敗
            this.$pool.worker_init_error(this);
        }

        this.$job.reject(err);

        this.$job = null;

        setTimeout(function () {
            debugger;
            // 通知 pool
            this.$pool.noticeByWorker(this);
        }, 0);
    }
    //--------------------------------------------------------------------------
    // 工作超時
    jobTimeout() {
        debugger;

        console.log("worker(%s)任務過時", this.$id);

        this.$job.timeout();

        this.$job = null;

        setTimeout(function () {
            // 申請離職
            // 因爲無法終止工作
            this.$pool.dismissWorker(this);

            // 通知 pool
            this.$pool.noticeByWorker();
        }, 0);
    }
    //--------------------------------------------------------------------------
    // @override
    getEndEvent() {
        throw new Error('need override _event_getEndEvent');
    }
    //--------------------------------------------------------------------------
    // @override
    getErrorEvent() {
        throw new Error('need override _event_getErrorEvent');
    }
}

export default WorkerProxy_abs;
