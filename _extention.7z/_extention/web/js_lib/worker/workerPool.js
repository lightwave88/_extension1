import $GM from './globalModule.js';

// 包裝 WorkerPool
// 避免露出太多内部私有函式
class WorkerPool_wrap {
    static getInstance(config) {
        return new WorkerPool_wrap(config);
    }
    //--------------------------------------------------------------------------
    constructor(config) {
        this.$core = new WorkerPool(config);
    }

    get config() {
        return this.$core.config;
    }
    //--------------------------------------------------------------------------
    // 執行任務
    execute(args) {
        this.$core.start();
        return this.$core.notice(args);
    }

    // 終止 pool 的任務
    close() {
        this.$core.close();
    }

    // 啓動
    // 預設是接到工作才啓動
    start() {
        this.$core.start();
    }

    importScripts(script) {
        this.$core.importScripts(script);
    }
    //--------------------------------------------------------------------------
    setConfig(config) {
        this.$core.setConfig(config);
    }
    //--------------------------------------------------------------------------
    // 設定 worker init 要執行的 callback
    setWorkerInit(...args) {
        this.$core.setWorkerInit(args);
    }
}

export default WorkerPool_wrap;
//==============================================================================

class WorkerPool {

    constructor(config) {

        // 旗標
        this.$flag = {
            inited: false
        };

        // 工作列表
        this.$jobList = [];

        // 工作人員
        this.$workers = new Set();

        // 是否有解雇的排程
        this.$schedule_handle = null;

        // setting
        this.$config = null;

        this.$importScripts = [];

        // worker 初始化要執行的
        this.$worker_init = {
            args: null,
            callback: null
        };
        //-----------------------
        const Config_class = $GM.get('Config');
        this.$config = Config_class.getInstance(config);
    }
    //--------------------------------------------------------------------------
    get config() {
        return this.$config.getConfig();
    }
    //--------------------------------------------------------------------------
    // 設定參數
    setConfig(config) {
        debugger;
        this.$config.setConfig(config);
    }

    importScripts(script) {
        if (!Array.isArray(script)) {
            script = [script];
        }

        this.$importScripts.concat(script);
    }
    //--------------------------------------------------------------------------
    // 設定 worker init 要執行的 callback
    setWorkerInit(args) {
        debugger;

        let callback = args.shift();

        if (typeof callback != 'function') {
            throw new TypeError('setInt(arg[0]) must be function');
        }


        this.$worker_init.args = args;
        this.$worker_init.callback = Function.prototype.toString.call(callback);
    }
    //--------------------------------------------------------------------------
    // 啓動 pool
    start() {
        debugger;
        if (this.$flag.inited) {
            return;
        }
        console.log('pool 初始化');
        this.$flag.inited = true;

        // 確定有足夠的核心員工
        this._checkCoreWorkerNum();
    }
    //--------------------------------------------------------------------------
    // API
    // 當外部有工作要托付執行
    notice(job_args) {
        debugger;
        console.log('外部呼叫，有新工作加入');

        const jobList = this.$jobList;

        if (this.$schedule_handle != null) {

            console.log('之前有排定裁員計劃，停止');
            // 有工作可接了，暫緩解職程序
            clearTimeout(this.$schedule_handle);
            this.$schedule_handle = null;
        }
        //------------------
        const Job_class = $GM.get('Job');
        let newJob;

        if (job_args instanceof Job_class) {
            newJob = job_args;
        } else {
            // 做成 job
            newJob = Job_class.getInstance(job_args);
        }
        debugger;
        // 新工作加入隊列
        jobList.push(newJob);
        //------------------
        // 分配工作
        let job;
        while (true) {
            debugger;

            if (jobList.length < 1) {
                break;
            }

            // 找員工接工作
            const worker = this._findWorker2takeJob();

            if (worker == null) {
                break;
            }
            job = jobList.shift();
            worker.takeJob(job);
        }
        return newJob.promise();
    }
    //--------------------------------------------------------------------------
    // API
    // worker 任務結束的囘報
    noticeByWorker(worker) {
        debugger;

        if (worker) {
            console.log('員工(%s)囘報', worker.$id_1);
        } else {
            console.log('離職員工回報');
        }
        //------------------
        if (worker == null) {
            // 有人離職了
            // 先確定有一定的核心工作人數
            this._checkCoreWorkerNum();
        }

        if (this.$jobList.length < 1) {
            // 沒有工作了，打算裁不必要的員工

            console.log('沒有工作了，打算裁不必要的員工');

            if (this.$schedule_handle != null) {
                console.log('已有裁員排程，不必再排');
            } else {
                // 若沒有解雇排程
                // 新增解雇排程
                this._dismissWorker_by_schedule();
            }

        } else {
            // 還有工作
            console.log('尚有工作要處理');

            if (this.$schedule_handle != null) {
                throw new Error('有裁員排程，奇怪點........');
            }

            if (worker != null) {
                // 你沒事就接工作吧

                console.log('由回報者接工作');

                let job = this.$jobList.shift();
                worker.takeJob(job);
            } else {
                // debugger;
                // 這位回報者無法接離職了
                // 找其他人接
                worker = this._findWorker2takeJob();

                if (worker != null) {

                    console.log('找來員工(%s)接工作', worker.$id_1);

                    job = this.$jobList.shift();
                    worker.takeJob(job);
                } else {
                    console.log('無人有空可接');
                }
            }
        }
    }
    //--------------------------------------------------------------------------
    // 停止 pool 的運作
    close() {

        if (this.$schedule_handle) {
            clearTimeout(this.$schedule_handle);
            this.$schedule_handle = null;
        }

        this.$flag.inited = false;

        this.$jobList.length = 0;

        this.$workers.forEach((w) => {
            w.terminate();
        });

        this.$workers.clear();
    }
    //--------------------------------------------------------------------------

    // 確定有足夠的核心員工
    _checkCoreWorkerNum() {
        debugger;
        const $config = this.$config;

        const corePoolSize = $config.corePoolSize;

        const $Worker_class = $GM.get('WorkerProxy')

        console.log('檢查核心員工數量，需(%s)位，現共有員工(%s)位', corePoolSize, this.$workers.size);

        while (corePoolSize > this.$workers.size) {
            debugger;
            console.log('核心員工不夠，補齊中');
            const worker = $Worker_class.getInstance(this);
            this.$workers.add(worker);
        }

        console.log('核心員工數量沒問題');
    }
    //--------------------------------------------------------------------------
    // 找人接工作
    _findWorker2takeJob() {
        debugger;
        console.log('找人接工作');

        const $config = this.$config;

        let idelWorker = null;
        // 找有空的接工作
        let {idle} = this._checkWorkersStatus();

        if (idle.length > 0) {
            // 既有員工有處在空閑的

            console.log('有閑閑員工可接');

            idelWorker = idle.pop();
            idle.length = 0;

        } else if (this.$workers.size < $config.maximumPoolSize) {
            // 若既有的員工都在忙
            // 但有餘額可招募新人

            const $Worker_class = $GM.get('WorkerProxy');

            console.log('既有的員工都在忙，但有餘額可招募新人');

            // 剛招募的人員
            let new_worker = $Worker_class.getInstance(this);
            this.$workers.add(new_worker);

            if (new_worker.$flag.initinated) {
                idelWorker = new_worker;
            }
        }

        if (idelWorker == null) {
            console.log('無人可接工作');
        }

        return idelWorker;
    }

    //--------------------------------------------------------------------------
    // 排程解雇多餘員工
    // 避免一下子解雇太多員工
    _dismissWorker_by_schedule() {
        debugger;

        if (!this._check_1()) {
            return;
        }

        console.log('排定裁員排程');
        //------------------
        const keepAliveTime = this.$config.keepAliveTime;

        this.$schedule_handle = setTimeout(() => {
            debugger;
            this.$schedule_handle = null;

            // 必須再做一次檢查
            // 避免計時器中間有變動
            if (this._check_1()) {
                console.log('裁撤空閑人員');

                // 先解雇一個沒事的員工
                const worker = idle.pop();

                // worker 離職後不要再多引發一次檢查
                worker.dismiss(false);
            }

            // 重新檢查
            this.noticeByWorker();

        }, keepAliveTime);
    }
    //--------------------------------------------------------------------------
    // 確定 workers 的狀態
    _checkWorkersStatus() {
        // debugger;

        const status = {
            init: [],
            busy: [],
            idle: [],
        };

        this.$workers.forEach((w) => {

            const flag = w.$flag;

            if (flag.initinated) {
                if (flag.busy) {
                    status.busy.push(w);
                } else {
                    status.idle.push(w);
                }
            } else {
                // 尚在初始化的員工
                status.busy.push(w);
                // status.idle.push(w);
                status.init.push(w);
            }
        });

        // console.log('員工資訊(%s)', JSON.stringify(status));
        return status;
    }
    //--------------------------------------------------------------------------
    _check_1() {
        if (this.$workers.size <= this.$config.corePoolSize) {
            // 再次確定有固定班底
            // 中間可能有人發生錯誤，或被强制關閉
            console.log('檢查發現固定班底人數有問題(%s, %s)，不裁員', this.$workers.size, this.$config.corePoolSize);
            return false;
        }

        const {idle, busy} = this._checkWorkersStatus();

        if (idle.length < 1) {
            console.log('沒有空閑中的人員，不裁員');
            return false;
        }

        if (idle.length == 1 && busy.length > 0) {
            // 有人在忙
            // 但只剩一人有空，就暫留
            console.log('有人在忙但只剩一人有空，就暫留不裁員');
            return false;
        }

        return true;
    }
    //--------------------------------------------------------------------------
    workerError(worker, er) {
        // 有 worker 初始化失敗
        throw new Error('worker(%s): %s', worker.$id_1, er);
    }
}


