import { $GM } from './globalModule.js';

// 包裝 WorkerPool
// 避免露出太多内部私有函式
class Pool {
    static getInstance(config) {
        return new Pool(config);
    }
    //--------------------------------------------------------------------------
    constructor(config) {
        debugger;

        this.$$$core;
        //------------------
        const $Config = $GM.get('Config');
        const $config = $Config.getInstance(config);
        this.$$$core = new WorkerPool($config);
    }
    //--------------------------------------------------------------------------
    setConfig(config) {
        this.$$$core.setConfig(config);
    }
    //--------------------------------------------------------------------------
    // 設定 worker init 要執行的 callback
    setWorkerInit(...args) {
        this.$$$core.setWorkerInit(args);
    }

    setImportScripts(script) {
        this.$$$core.setImportScripts(script);
    }

    init() {
        this.$$$core.init();
    }
    //--------------------------------------------------------------------------
    // 執行任務
    execute(args) {
        return this.$$$core.notice(args);
    }

    get "is_inited"() {
        return this.$$$core.$inited;
    }
}

export default Pool;
//==============================================================================

class WorkerPool {

    constructor(config) {

        this.$inited = false;

        // setting
        this.$config = config;

        // 工作列表
        this.$jobList = [];

        // 工作人員
        this.$workers = new Set();

        // 是否有解雇的排程
        this.$schedule_handle = null;

        this.$importScripts = [];

        // worker 初始化要執行的
        this.$worker_init = {
            args: null,
            callback: null
        };
        //-----------------------

    }
    //--------------------------------------------------------------------------
    get timeout() {
        return (this.$config.timeout != null ? this.$config.timeout : null);
    }
    //--------------------------------------------------------------------------
    // 設定參數
    setConfig(config) {
        debugger;
        this.$config.setConfig(config);
    }

    setImportScripts(script) {
        if (!Array.isArray(script)) {
            script = [script];
        }

        this.$importScripts.concat(script);
    }
    //--------------------------------------------------------------------------
    // 設定 worker init 要執行的 callback
    setWorkerInit(args) {
        debugger;

        let callback = args.shift();

        if (typeof callback != 'function') {
            throw new TypeError('setInt(arg[0]) must be function');
        }
        this.$worker_init.args = args;
        this.$worker_init.callback = fun2String(callback);
    }
    //--------------------------------------------------------------------------
    init() {
        debugger;
        if (this.$inited) {
            return;
        }
        this.$inited = true;

        // 確定有足夠的核心員工
        this.checkCoreWorkerNum();
    }
    //--------------------------------------------------------------------------
    // 當外部有工作要托福執行
    notice(job_args) {
        debugger;
        console.log('外部呼叫，有新工作加入');

        const jobList = this.$jobList;

        if (this.$schedule_handle != null) {

            console.log('之前有排定裁員計劃，停止');
            // 有工作可接了，暫緩解職程序
            clearTimeout(this.$schedule_handle);
            this.$schedule_handle = null;
        }
        //------------------
        const $Job_class = $GM.get('Job');

        // 做成 job
        let join_job = $Job_class.getInstance(job_args);

        debugger;
        // 新工作加入隊列
        jobList.push(join_job);

        // 分配工作
        let job;
        while (true) {
            debugger;

            if (jobList.length < 1) {
                break;
            }

            // 找員工接工作
            const worker = this.findWorker2takeJob();

            if (worker == null) {
                break;
            }
            job = jobList.shift();
            worker.takeJob(job);
        }
        return join_job.promise();
    }
    //--------------------------------------------------------------------------
    // worker 任務結束的囘報
    noticeByWorker(worker) {
        debugger;

        const config = this.$config;

        console.log('員工(%s)囘報', (worker != null ? worker.$id : ''));

        if (!this.$jobList.length) {
            // 沒有工作了，打算裁不必要的員工

            console.log('沒有工作了，打算裁不必要的員工');

            if (this.$workers.size <= config.corePoolSize) {
                // 只剩核心員工，不用裁員
                console.log('只剩核心員工(%s)位，不用裁員', this.$workers.size);
                return;
            }

            if (this.$schedule_handle != null) {
                console.log('已有裁員排程，不必再排');
            } else {
                // 若沒有解雇排程
                // 新增解雇排程
                this.dismissWorker_by_schedule();
            }

        } else {
            // 還有工作           

            console.log('尚有工作要處理');

            if (this.$schedule_handle != null) {
                throw new Error('有裁員排程，奇怪點........');
            }

            if (worker != null) {
                // 你沒事就接工作吧

                console.log('由回報者接工作');

                let job = this.$jobList.shift();
                worker.takeJob(job);
            } else {
                debugger;
                // 這位回報者無法接離職了
                // 找其他人接

                // 先確定有一定的核心工作人數
                this.checkCoreWorkerNum();

                worker = this.findWorker2takeJob();

                if (worker != null) {
                    job = this.$jobList.shift();
                    worker.takeJob(job);
                }
            }
        }
    }
    //--------------------------------------------------------------------------

    // 確定有足夠的核心員工
    checkCoreWorkerNum() {
        debugger;
        const $config = this.$config;

        const corePoolSize = $config.corePoolSize;

        const WorkerProxy = $GM.get('WorkerProxy')

        console.log('檢查核心員工數量，需(%s)位，現共有員工(%s)位', corePoolSize, this.$workers.size);

        while (corePoolSize > this.$workers.size) {
            debugger;
            console.log('核心員工不夠，補齊中');
            const worker = WorkerProxy.getInstance(this);
            this.$workers.add(worker);
        }

        console.log('核心員工數量沒問題');
    }
    //--------------------------------------------------------------------------
    // 找人接工作
    findWorker2takeJob() {
        debugger;
        console.log('找人接工作');

        const $config = this.$config;

        let idelWorker = null;
        // 找有空的接工作
        let {idle} = this.checkWorkersStatus();

        if (idle.length > 0) {
            // 既有員工有處在空閑的

            console.log('有閑閑員工可接');

            idelWorker = idle.pop();
            idle.length = 0;

        } else if (this.$workers.size < $config.maximumPoolSize) {
            // 若既有的員工都在忙
            // 但有餘額可招募新人

            const $Worker_class = $GM.get('WorkerProxy');

            console.log('既有的員工都在忙，但有餘額可招募新人');

            // 剛招募的人員
            let new_worker = $Worker_class.getInstance(this);
            this.$workers.add(new_worker);

            if (new_worker.$flag.initinated) {
                idelWorker = new_worker;
            }
        }

        if (idelWorker == null) {
            console.log('無人可接工作');
        }

        return idelWorker;
    }

    //--------------------------------------------------------------------------
    // 排程解雇多餘員工
    // 避免一下子解雇太多員工
    dismissWorker_by_schedule() {
        debugger;

        console.log('排定裁員排程');

        const keepAliveTime = this.$config.keepAliveTime;

        this.$schedule_handle = setTimeout(() => {
            debugger;
            // 先解雇一個沒事的員工
            this.dismissIdleWorker(1);
            this.$schedule_handle = null;

            // 重新檢查
            this.noticeByWorker();
        }, keepAliveTime);
    }
    //--------------------------------------------------------------------------
    // 辭退某個員工
    // 若沒指定那個員工則辭退多餘員工
    dismissWorker(worker) {
        debugger;

        console.log('裁員(%s)', worker.id);

        if (!this.$workers.has(worker)) {
            throw new Error(`no this worker(${worker.id}) to dismiss`)
        }

        this.$workers.delete(worker);
        worker.terminate();
    }
    //--------------------------------------------------------------------------
    dismissIdleWorker(count = 1) {
        debugger;

        const {idle} = this.checkWorkersStatus();

        for (let i = 0; (i < idle.length && i < count); i++) {
            const worker = idle[i];
            this.dismissWorker(worker);
    }
    }
    //--------------------------------------------------------------------------
    // 確定 workers 的狀態
    checkWorkersStatus() {
        // debugger;

        const status = {
            init: [],
            busy: [],
            idle: [],
        };

        this.$workers.forEach((w) => {

            const flag = w.$flag;

            if (flag.initinated) {
                if (flag.busy) {
                    status.busy.push(w);
                } else {
                    status.idle.push(w);
                }
            } else {
                // 尚在初始化的員工
                status.busy.push(w);
                // status.idle.push(w);
                status.init.push(w);
            }
        });

        // console.log('員工資訊(%s)', JSON.stringify(status));
        return status;
    }

    worker_init_error(worker) {
        // 有 worker 初始化失敗        

        this.dismissWorker(worker);

        throw new Error('worker init error');
    }
}


function fun2String(fun) {
    return Function.prototype.toString.call(fun);
}