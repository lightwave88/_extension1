import { $GM } from './globalModule.js';

class Pool {
    static getInstance(config) {
        return new Pool(config);
    }

    constructor(config) {
        debugger;

        this.$$$core;
        //------------------
        const $Config = $GM.get('Config');
        const $config = $Config.getInstance(config);
        // this.$$$core = new WorkerPool($config);
    }

    setConfig(config) {
        this.$$$core.setConfig(config);
    }

    execute(job_options) {
        return this.$$$core.notice(job_options);
    }
}

export default Pool;
//==============================================================================

class WorkerPool {

    constructor(config) {
        // setting
        this.config = config;

        // 工作列表
        this.jobList = [];

        // 工作人員
        this.workers = new Set();

        // 是否有解雇的排程
        this.schedule_handle = null;
    }
    // 設定參數
    setConfig(config) {
        this.config.setConfig(config);
    }

    get timeout() {
        return (this.config.timeout != null ? this.config.timeout : null);
    }
    //--------------------------------------------------------------------------
    // 當外部有工作要托福執行
    notice(job_options) {
        console.log('外部呼叫，有新工作');

        if (this.schedule_handle != null) {

            console.log('暫緩解職程序');
            // 有工作可接了，暫緩解職程序
            clearTimeout(this.schedule_handle);
            this.schedule_handle = null;
        }
        //------------------
        const $Job_class = $GM.get('job_class');

        // 做成 job
        let job = $Job_class.getInstance(job_options);

        this.jobList.push(job);
        //------------------
        let worker = this.findWorker2takeJob();

        if (worker != null) {
            job = this.jobList.shift();
            worker.takeJob(job);
        }

        return job.promise();
    }

    // worker 任務結束的匯報
    noticeByWorker(worker) {

        const config = this.config;

        console.log('員工(%s)囘報', (worker != null ? worker.id : ''));

        if (!this.jobList.length) {
            // 沒有工作了，打算裁不必要的員工

            console.log('沒有工作了，打算裁不必要的員工');

            if(this.workers.size <= config.corePoolSize){
                // 只剩核心員工，不用裁員

                console.log('只剩核心員工(%s)位，不用裁員', this.workers.size);

                return;
            }

            if (this.schedule_handle != null) {

                console.log('已有裁員排程，不必再排');
            } else {

                // 若沒有解雇排程
                // 新增解雇排程
                this.dismissWorker_by_schedule();
            }

        } else {
            // 還有工作           

            console.log('尚有工作要處理');

            if(this.schedule_handle != null){
                console.log('有裁員排程，奇怪點........');
            }


            if (worker != null) {
                // 你沒事就接工作吧

                console.log('由回報者接工作');

                job = this.jobList.shift();
                worker.takeJob(job);
            } else {
                // 這位回報者無法接
                worker = this.findWorker2takeJob();

                if (worker != null) {
                    job = this.jobList.shift();
                    worker.takeJob(job);
                }
            }
        }
    }
    //--------------------------------------------------------------------------
    // 找人接工作
    findWorker2takeJob() {
        console.log('找人接工作');

        const $config = this.config;

        for (let shortfall = ($config.corePoolSize - this.workers.size); shortfall > 0;) {
            // 確定招募足夠的核心成員

            console.log('核心成員不夠，補齊中');

            const worker = null;
            this.workers.add(worker);
        }

        let idelWorker = null;
        // 找有空的接工作
        let { idle } = this.checkWorkersStatus();

        if (idle.length > 0) {
            // 既有員工有處在空閑的

            console.log('有員工可接');

            idelWorker = idle.pop();
            idle.length = 0;
        } else if (this.workers.size < $config.maximumPoolSize) {
            // 若既有的員工都在忙
            // 但有餘額可招募新人

            const $Worker_class = $GM.get('workerProxy_class');

            console.log('既有的員工都在忙，但有餘額可招募新人');
            idelWorker = new $Worker_class(this);
        }

        if (idelWorker == null) {
            console.log('無人可接工作');
        }

        return idelWorker;
    }

    //--------------------------------------------------------------------------
    // 排程解雇多餘員工
    // 避免一下子解雇太多員工
    dismissWorker_by_schedule() {

        console.log('排定裁員排程');

        const keepAliveTime = this.config.keepAliveTime;

        this.schedule_handle = setTimeout(() => {
            // 先解雇一個沒事的員工
            this.dismissIdleWorker(1);
            this.schedule_handle = null;

            // 重新檢查
            this.noticeByWorker();
        }, keepAliveTime);
    }
    //--------------------------------------------------------------------------
    // 辭退某個員工
    // 若沒指定那個員工則辭退多餘員工
    dismissWorker(worker) {

        console.log('裁員(%s)', worker.id);

        if (!this.workers.has(worker)) {
            throw new Error(`no this worker(${worker.id}) to dismiss`)
        }

        this.workers.delete(worker);
        worker.terminate();
    }
    //--------------------------------------------------------------------------
    dismissIdleWorker(count = 1) {
        const { idle } = this.checkWorkersStatus();

        for (let i = 0; (i < idle.length && i < count); i++) {
            const worker = idle[i];
            this.dismissWorker(worker);
        }
    }
    //--------------------------------------------------------------------------
    // 確定 workers 的狀態
    checkWorkersStatus() {
        const status = {
            init: [],
            busy: [],
            idle: [],
        };

        this.workers.forEach((w) => {

            if (w.flag.inited) {
                if (w.flag.busy) {
                    status.busy.push(w);
                } else {
                    status.idle.push(w);
                }
            } else {
                status.busy.push(w);
                status.init.push(w);
            }
        });

        return status;
    }
}