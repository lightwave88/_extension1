
class Job {
    static getInstance(args) {
        return new Job(args);
    }
    //--------------------------------------------------------------------------
    constructor(args = []) {
        // debugger;
        this.$args = args;

        this.$promise = new Promise((_res, _rej) => {
            this.resolve = function (res) {
                _res(res);
            }
            this.reject = function (err) {
                _rej(err);
            }
        });
    }
    //--------------------------------------------------------------------------
    promise() {
        return this.$promise;
    }
    //--------------------------------------------------------------------------
    // 取得任務内容
    getCommand(worker) {
        // debugger;

        const command = {
            command: null,
            action: null,
            args: [],
            funList: [],
            id: worker.$id
        };
        let args = this.$args.slice();

        const first = args.shift();

        args.forEach((arg, i) => {
            if (typeof arg == 'function') {
                command.funList.push(i);
                arg = getFnContent(arg);
            }
            command.args.push(arg);
        });

        // debugger;
        if (typeof first == 'string') {
            command.command = first;
        } else if (typeof first == 'function') {
            command.action = getFnContent(first);
        } else {
            throw new TypeError('unaccept type of args[0] (' + typeof (first) + ')' + first);
        }
        return command;
    }
}

export default Job;

function getFnContent(fn) {
    return Function.prototype.toString.call(fn);
}


