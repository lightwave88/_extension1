import $GM from './globalModule.js';

class Job_wrap {

    static getInstance(args) {
        return new Job_wrap(args);
    }
    //--------------------------------------------------------------------------
    constructor(args = []) {
        this.$$$core = new Job(args);
    }

    promise() {
        return this.$$$core.$deferred;
    }

    stop() {
        this.$$$core.close();
    }

    onMessage(callback) {
        this.$$$core.onMessage(callback);
    }
}

export default Job_wrap;
//------------------------------------------------------------------------------
class Job {

    constructor(args = []) {
        // debugger;
        this._ = $GM.get('_');
        this.$fn = Job;
        this.$worker;
        this.$pool;
        this.$args = args;
        this.$callbackList = [];

        this.$deferred = this._.deferred();
    }
    setWorker(worker) {
        this.$worker = worker;
        this.$pool = this.$worker.$pool;
    }
    //--------------------------------------------------------------------------
    promise() {
        return this.$deferred;
    }

    resolve(d) {
        this.$deferred.resolve(d)
    }

    reject(er) {
        this.$deferred.reject(er);
    }

    // 手動結束使用中的 worker
    stop() {
        this.$worker.user_stopJop();

        this.$deferred.resolve();
    }

    postMsg(msg) {
        this.$worker.postMessage(msg);
    }

    onMsg(callback) {
        if (typeof callback != 'function') {
            throw new Error('arg[0] must be function');
        }
        this.$callbackList.push(callback);
    }
    //--------------------------------------------------------------------------
    // 取得任務内容
    getJobContent() {
        debugger;       

        const jobContent = {
            cmd: null,
            act: null,
            args: [],
            funList: []
        };
        let args = this.$args.slice();

        const first = args.shift();

        args.forEach((arg, i) => {
            if (typeof arg == 'function') {
                jobContent.funList.push(i);
                arg = $tools.fun2String(arg);
            }
            jobContent.args.push(arg);
        });

        // debugger;
        if (typeof first == 'string') {
            jobContent.cmd = first;
        } else if (typeof first == 'function') {
            jobContent.act = Function.prototype.toString.call(first);
        } else {
            throw new TypeError('unaccept type of args[0] (' + typeof (first) + ')' + first);
        }
        return jobContent;
    }

    //--------------------------------------------------------------------------
    // worker 收到訊息
    recieveMsg(msg) {
        this.$callbackList.forEach((fun) => {
            fun(msg);
        });
    }
}






