
const $config = {
    ob_key: "_@_ob_@_",
};
//------------------------------------------------------------------------------`
class Config {
    static getInstance() {
        return new Config();
    }
    //--------------------------------------------------------------------------
    set(k, v) {
        $config[k] = v;
    }
    //--------------------------------------------------------------------------
    get(k = null) {
        let res = null;
        if (k != null && (k in $config)) {
            res = $config[k];
        } else {
            res = Object.assign({}, $config);
        }

        return res;
    }
}

const $instance = Config.getInstance();
export default $instance;

