import $GM from './gmodule.js';

class CheckSystem {
    
    static getInstance(){
        return new CheckSystem();
    }
    
    constructor() {
        this.root;
    }
    //--------------------------------------------------------------------------
    check() {
        debugger;
        this.root = this._checkRoot();
        let _;

        _ = this.root._;

        if (_ == null) {
            throw new Error('no impoert _');
        }

        $GM.set('_', _);
    }
    //--------------------------------------------------------------------------
    _checkRoot() {
        let root;

        if (typeof self == 'object' && self.self === self) {
            root = self;
        } else if (typeof global == 'object' && global.global === global) {
            root = global;
        }
        root = root || this;

        return root;
    }
}

export default CheckSystem;

