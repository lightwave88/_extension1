import $GM from './gmodule.js';

const $tool = {

    //--------------------------------------------------------------------------
    getObjectClass(obj) {
        let _toString = Object.prototype.toString;

        let type = typeof (obj);

        if (/object/.test(type)) {

            if (data === null) {
                type = "null";
            } else {
                type = _toString.call(obj);

                let res = /\[\w+\s+(\w+)\]/.exec(type);
                if (res && res[1]) {
                    type = res[1];
                }
            }
        }

        return type;
    },
    //--------------------------------------------------------------------------
    isCollect(data) {
        if (Array.isArray(data)) {
            return true;
        } else if (this.isPlainObject(data)) {
            return true;
        }
        return false;
    },
    //--------------------------------------------------------------------------
    isPlainObject(obj) {
        if (typeof obj != "object") {
            return false;
        }

        if (obj == null) {
            return false;
        }

        let res = Object.prototype.toString.call(obj);

        if (!/^\[object Object\]$/.test(res)) {
            return false;
        }

        if (obj.constructor !== {}.constructor) {
            return false;
        }

        return true;
    },
    //--------------------------------------------------------------------------
    defProperty(obj, key, val, enumerable) {
        Object.defineProperty(obj, key, {
            value: val,
            enumerable: !!enumerable,
            writable: true,
            configurable: true
        });
    },
    //--------------------------------------------------------------------------
    // 針對 array
    protoAugment(target, src) {
        target.__proto__ = src;
    },
    //--------------------------------------------------------------------------
    // 針對 array
    copyAugment(target, src) {
        const keys = Object.getOwnPropertyNames(src);
        
        for (var i = 0, l = keys.length; i < l; i++) {
            var key = keys[i];
            this.defProperty(target, key, src[key]);
        }
    },
    //--------------------------------------------------------------------------
    // for test
    // 未來用 _.workPool() 取代
    async_looseEqual(a, b) {
        return new Promise((resolve, rej) => {
            setTimeout(() => {
                let res = this.looseEqual(a, b);
                resolve(res);
            }, 0);
        });
    },
    //--------------------------------------------------------------------------
    looseEqual(a, b) {
        debugger;

        let isCollect_a = this.isCollect(a);
        let isCollect_b = this.isCollect(b);

        // 相同的集合即使有相同值
        // 系統仍認為是不同
        // 必須進一步手動處理
        //----------------------------
        if (isCollect_a && isCollect_b) {
            // 物件相比

            if (Array.isArray(a) && Array.isArray(b)) {
                // 二者同為 array

                if (a.length === b.length) {
                    return a.every(function (e, i) {
                        let res = this.looseEqual(e, b[i]);
                        return res;
                    });
                } else {
                    return false;
                }
            } else if (!Array.isArray(a) && !Array.isArray(b)) {
                // 二者同為 plaingObj

                var keysA = Object.getOwnPropertyNames(a);
                var keysB = Object.getOwnPropertyNames(b);

                if (keysA.length === keysB.length) {
                    return keysA.every(function (key) {
                        let res = this.looseEqual(a[key], b[key]);
                        return res;
                    });
                } else {
                    return false;
                }

            } else {
                // 兩集合的形態不同
                return false
            }

        } else {
            // 不屬於集合形態
            // 包含物件與基本形態

            // 形態相同比值
            return Object.is(a === b);
        }
    },
    //--------------------------------------------------------------------------
    filterPath() {

    },
    //--------------------------------------------------------------------------
    cloneValue(data) {
        let value = data;

        if (data != null && (typeof data == 'object')) {
            try {
                value = JSON.stringify(data);
                value = JSON.parse(value);
            } catch (error) {
                console.log(error);
            }
        }
        return value;
    },

};

export default $tool;

