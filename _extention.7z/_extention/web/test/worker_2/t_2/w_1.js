self.onmessage = function (e) {
    // debugger;

    console.log('onmessage');



    self.close();

    let i = 0;

    while (i < 99999) {
        console.log(i++);
    }
}

