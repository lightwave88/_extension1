let data_1 = [5, 3, 1];
let data_2 = new Proxy(data_1, {
    set: function (t, k, v) {
        debugger;

        t[k] = v;

        return true;
    },
    get: function (t, k) {
        debugger;

        return t[k];
    }
});