debugger;
self.onmessage = (e)=>{
    debugger;
    console.dir(e);
    self.postMessage(e.data);    
}

self.postMessage('finish');