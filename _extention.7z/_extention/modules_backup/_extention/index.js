
// _extension 本體
require('_extension/head');

//==============================================================================
debugger;
// 引入其他模組
require('./basicTools');

debugger;
// require('./worker');