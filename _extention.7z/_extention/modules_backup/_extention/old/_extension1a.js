// 對外擴充方法
let Output = (function ($global) {
    // //////////////////////////////////////////////////////////////////////////
    //
    // extension_1
    //
    // //////////////////////////////////////////////////////////////////////////
    // 資訊
    const _extension1 = {
        callback_uid: 1,
        "_": null,
        info: {
            sourceScriptPath: null,
            extension1ScriptPath: null,
            environment: null,
        }
    };

    const ImportModuleList = [];
    // ==========================================================================
    // 工廠函式
    class Factory {
        // ----------------------------
        // 取得 _, _extention 的路徑
        static _getPath() {
            const info = _extension1.info;

            if (/nodejs/.test(this.environment)) {

                info.extension1ScriptPath = __dirname;

            } else if (/browser/.test(this.environment)) {

                if (typeof document == 'undefined') {
                    return;
                }

                let scripts = Array.from(document.querySelectorAll('script'));
                let script = scripts.pop();

                info.extension1ScriptPath = script.src;
                // ----------------------------
                // find scriptPath
                let reg = /(\\|\/)?([^\/]*?(underscore|lodash)[^\/]*?)$/i;

                while ((script = scripts.pop()) != null) {
                    let src = script.src;
                    if (src && reg.test(src)) {
                        info.sourceScriptPath = src;
                        break;
                    }
                }
            }
        }
        // ----------------------------
        static _final() {
            Object.defineProperty(this._, '$extension1', {
                value: _extension1,
                enumerable: false,
                writable: false,
                configurable: true
            });
        }
        // ----------------------------
        static main() {
            const _ = _extension1._;

            if (_ == null) {
                throw new Error('no import _');
            }

            if (_.$extension1 != null) {
                // 避免重複
                return;
            }

            Factory._getPath();

            Factory._final();
        }
    }
    // ==========================================================================

    class ImportModules {
        // API
        static importModules(m) {
            // debugger
            const environment = _extension1.info.environment;
            const _ = _extension1._;

            switch (environment) {
                case 'nodejs':
                    if (_ == null) {
                        // _尚未引入，先將模組放置等候區
                        ImportModuleList.push(m);
                    } else {
                        m(_extension1);
                    }
                    break;
                default:
                    if (_ == null) {
                        throw new Error('_extension1 need import _');
                    } else {
                        m(_extension1);
                    }
                    break;
            }
        }
        // -----------------------
        // nodejs
        static injectModules() {
            if (G._ == null) {
                return;
            }
            let m;

            while ((m = ImportModuleList.shift()) != null) {
                m(_extension1);
            }
        }
    }

    // ==========================================================================

    (function checkEnviroment() {
        // debugger
        // 環境檢測

        if (typeof window != 'undefined' && typeof document != 'undefined') {
            // browser

            let environment = 'browser';
            let _ = window._;

            _extension1._ = _;
            _extension1.info.environment = environment;

            Factory.main();
        } else if (typeof (module) != 'undefined' && typeof (module.exports) != 'undefined') {

            _extension1.info.environment = 'nodejs';

            // node.js
            // arg: [_.path: _的路徑， _obj: _本身]
            module.exports = function (arg) {
                let _;
                let _path;

                if (typeof arg == 'string') {
                    _ = require(path);
                } else {
                    _ = arg;
                }
                // 取得 _ 在本機的位置
                _path = require.resolve(path);

                _extension1.info.sourceScriptPath = _path;

                Factory.main();

                ImportModules.injectModules();

                return _;
            }
        } else if (typeof (window) == 'undefined' && self != 'undefined' && typeof (importScripts) == 'function') {
            // webWorker 環境
            _extension1.info.environment = 'worker';
            _extension1._ = self._;

            Factory.main();
        } else {
            throw new Error('no support this system');
        }
    }())

    // ==========================================================================
    const Output = {};

    
    // 對外引入模組的函式
    Output.importModules = function (m) {
        ImportModules.importModules(m);
    }

    return Output;
})(this || {})

// 個模組匯入的方式
// 方便 php 的彙整
const ImportModules = Output.importModules;
Output = undefined;
