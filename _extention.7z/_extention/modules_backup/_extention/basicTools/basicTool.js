{

    const $injectModules = {};
    {
        // isPlainObject
        $injectModules['isPlainObject'] = {
            override: false,
            fun: isPlainObject
        };

        function isPlainObject(obj) {

            if (typeof obj != "object") {
                return false;
            }

            if (obj == null) {
                return false;
            }

            let res = Object.prototype.toString.call(obj);

            if (!/^\[object Object\]$/.test(res)) {
                return false;
            }

            if (obj.constructor !== {}.constructor) {
                return false;
            }

            return true;
        }
    }
    //==========================================================================

    {
        // getClassName

        $injectModules['getClassName'] = {
            override: false,
            fun: getClassName
        };

        function getClassName(data) {
            let _toString = Object.prototype.toString;

            let type = typeof (data);

            if (/object/.test(type)) {

                if (data === null) {
                    type = "null";
                } else {
                    type = _toString.call(data);

                    let res = /\[\w+\s+(\w+)\]/.exec(type);
                    if (res && res[1]) {
                        type = res[1];
                    }
                }
            }
            return type;
        }
    }
    //==========================================================================
    {
        // job: [function|promise]
        $injectModules['timeout'] = {
            override: false,
            fun: timeout
        };


        function timeout(job, timeLimit, context) {
            let p1;

            if (typeof timeLimit != 'number') {
                throw new TypeError("timeout arg[1] must be number");
            }

            if (typeof (job) == "function") {

                if (context != null) {
                    job = job.bind(context);
                }
                p1 = new Promise(job);
            } else if (job instanceof Promise) {
                p1 = job;
            } else {
                throw new TypeError("timeout arg[0] must be promise or function");
            }
            //-----------------------
            let _res;
            let _rej;

            let r_p = new Promise(function (res, rej) {

                _res = res;
                _rej = rej;
            });
            //-----------------------
            // 計時器
            let timeHandle = setTimeout(() => {
                _rej(new Error('timeout'));
            }, timeLimit);


            p1.then((data) => {

                clearTimeout(timeHandle);
                timeHandle = null;
                _res(data);
            }, (err) => {
                clearTimeout(timeHandle);
                timeHandle = null;
                _rej(err);
            });
            //-----------------------

            return r_p;
        }
    }
    //==========================================================================
    {

        // promise
        //
        // callback: [function(返回 promise)|promise[]]
        // context: 背後執行對象
        $injectModules['promise'] = {
            override: false,
            fun: _promise
        };

        function _promise(callback, context) {
            let p;

            if (callback instanceof Promise) {
                p = Promise.resolve(callback);
            } else if (typeof (callback) == "function") {

                (callback == null) || (callback.bind(context));

                p = new Promise(callback);
            } else if (Array.isArray(callback)) {

                if (context != null) {
                    callback = callback.map(function (fn) {
                        return fn.bind(context);
                    });
                }
                p = Promise.all(callback);
            } else {
                p = Promise.resolve(callback);
            }
            //-----------------------
            if (p['$status'] == null) {
                Object.defineProperty(p, '$status', {
                    value: 0,
                    enumerable: false,
                    writable: true,
                    configurable: true
                });
            }
            p.then(function () {
                p['$status'] = 1;
            }, function (err) {
                p['$status'] = 2;
                err = (err instanceof Error) ? err : new Error(err);
                throw err;
            });

            return p;
        }
    }
    //==========================================================================
    {
        // deferred

        // 模組範圍

        class Deferred {

            constructor() {
                this.fn = Deferred;
                this._reject;
                this._resolve;
                this._promise;

                this._promise = new Promise((resolve, reject) => {
                    this._resolve = (d) => {
                        this.$$$setStatus(1);
                        resolve(d);
                    };
                    this._reject = (er) => {
                        this.$$$setStatus(2);
                        reject(er);
                    };
                });

                Object.defineProperty(this._promise, '$status', {
                    value: 0,
                    enumerable: false,
                    writable: true,
                    configurable: true
                });

                this.$$$setProperty();

                this.$$$setStatus(0);
            }

            $$$setProperty() {
                // 防止修改 this.status

                let target = this._promise;

                Object.defineProperty(this, 'status', {
                    enumerable: true,
                    configurable: true,
                    get: function () {
                        return target['$status'];
                    },
                    set: function () {
                        return;
                    }
                });
            }

            promise() {
                return this._promise;
            }
            //------------------------------------------------------------------
            resolve(arg) {
                this._resolve(arg);
            }
            //------------------------------------------------------------------
            reject(err) {
                this._reject(err);
            }
            //------------------------------------------------------------------
            then(onFulfilled, onRejected) {
                var def = Deferred();
                var p = this.promise();

                p = p.then(this.$$$getCallback(onFulfilled),
                    this.$$$getErrorCallback(onRejected));
                //-----------------------
                p.then(function (data) {
                    def.resolve(data);
                }, function (error) {
                    def.reject(error);
                });
                return def;
            }
            //------------------------------------------------------------------
            catch(onRejected) {
                var def = Deferred();
                var p = this.promise();

                p = p.catch(this.$$$getErrorCallback(onRejected));
                //-----------------------
                p.then(function (data) {
                    def.resolve(data);
                }, function (error) {
                    def.reject(error);
                });
                return def;
            }
            //------------------------------------------------------------------
            always(callback) {
                var def = Deferred();
                var p = this.promise();

                p = p.then(this.$$$getAlwaysCallback(callback, false),
                    this.$$$getAlwaysCallback(callback, true));
                //-----------------------
                p.then(function (data) {
                    def.resolve(data);
                }, function (error) {
                    def.reject(error);
                });
                return def;
            }
            //------------------------------------------------------------------ 
            status() {
                return this._promise['$status'];
            }
            //------------------------------------------------------------------
            isPending() {
                return (this._promise['$status'] == 0);
            }
            //------------------------------------------------------------------
            isFulfilled() {
                return (this._promise['$status'] == 1);
            }
            //------------------------------------------------------------------
            isRejected() {
                return (this._promise['$status'] == 2);
            }
            //------------------------------------------------------------------
            $$$setStatus(status) {
                this._promise['$status'] = status;
            }
            //------------------------------------------------------------------
            $$$getCallback(callback, context) {
                if (callback == null) {
                    return null;
                }

                callback = (context === undefined ? callback : callback.bind(context));

                return function (d) {
                    return callback(d);
                };
            }
            //------------------------------------------------------------------
            $$$getErrorCallback(callback, context) {
                if (callback == null) {
                    return null;
                }

                callback = (context === undefined ? callback : callback.bind(context));

                return function (err) {
                    return callback(err);
                };
            }
            //------------------------------------------------------------------
            $$$getAlwaysCallback(callback, args, context) {
                if (callback == null) {
                    return null;
                }

                callback = (context === undefined ? callback : callback.bind(context));

                return function (d) {
                    return callback(args, d);
                };
            }
        }

        Deferred.status = ['pending', 'fulfilled', 'rejected'];


        $injectModules['deferred'] = {
            override: false,
            fun() {
                return new Deferred();
            }
        };
    }
    //==========================================================================
    (() => {
        // initialize
        let $root;

        if (typeof module != 'undefined' && module.exports) {
            // nodejs

            // debugger;
            const $extension = require('_extension');
            $extension.mixin($injectModules);
            return;
        }
        //------------------
        $root = self || this;
        const _ = $root._;

        if (_ == null) {
            throw new Error("no import _");
        }
        _['$$$extension'].mixin($injectModules);
    })();

}