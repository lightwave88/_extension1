debugger;
const $GM = require('./globalModule.js');

function API() {
}

module.exports = API;

(function () {

    this.set = function () {

    };

    this.setMaxWorkers = function () {

    };

    this.setMinWorkers = function () {

    };

    this.setIdleTime = function () {

    };
    //------------------
    this.setPath = function () {

    };

    this.setTimeout = function () {

    };
    //------------------
    this.setExtensionPath = function () {

    };

    //------------------
    // worker 必須額外載入的 script
    this.importScript = function (script) {

    };

}).call(API);