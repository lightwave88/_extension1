

///////////////////////////////////////////////////////////////////////////////
//
// 預設 worker 會彈性隨效能在(max_workers, min_workers)之間調整數量
//
// 但若不想 worker 的數量自動彈性調整，可以設定(max_workers = min_workers)
//
///////////////////////////////////////////////////////////////////////////////



const $default_config = {};

(function () {


    // 同時能運行最大的 worker 數量
    this.max_workers = 2;

    // idle 時要維持幾個 workers 待命
    this.min_workers = 0;

    // 當 worker 沒任務可接時
    // 閒置多久後會被銷毀
    this.idleTime = (1000 * 30);

    // (uderscore, lodash) url
    this['_path'] = null;

    // extension1.url
    this.extensionPath = null;

    // 要被 import 的 script
    this.importScriptList = new Set();

    // 任務的時限，預設無時限
    this.timeout = 0;

}).call($default_config);
//--------------------------------------
// defaultSetting 的包覆者
// 可以做輸入驗證
const init_checkPropertyList = [];

let singleton;

class Config {
    static getInstance() {
        if (singleton == null) {
            singleton = new Config();
        }

        return singleton;
    }

    constructor() {
        this.$$$config = Object.assign({}, $default_config);
    }
    //--------------------------------------------------------------------------
    set max_workers(count) {
        count = Number(count);

        const setting = this.$$$config;

        const errorList = [];

        if (count < setting.min_workers) {
            errorList.push(`max_workers < min_workers(${setting.min_workers})`);
        }

        if (count < 1) {
            errorList.push('max_workers must < 1');
        }

        if (errorList.length) {
            let msg = errorList.join("\n");
            throw new Error(msg);
        }

        setting.max_workers = count;
    }

    get max_workers() {
        return this.$$$config.max_workers;
    }
    //--------------------------------------------------------------------------
    set min_workers(count) {

        count = Number(count);

        const setting = this.$$$config;

        const errorList = [];

        if (count > setting.max_workers) {
            errorList.push(`min_workers > max_workers(${setting.max_workers})`);
        }

        if (count < 0) {
            errorList.push('min_workers < 0');
        }

        if (errorList.length) {
            let msg = errorList.join("\n");
            throw new Error(msg);
        }

        setting.min_workers = count;
    }

    get min_workers() {
        return this.$$$config.min_workers;
    }
    //--------------------------------------------------------------------------
    set idleTime(time) {

        time = Number(time);

        if (time < 0) {
            throw new Error("idleTime must be >= 0");
        }

        this.$$$config.idleTime = time;
    }

    get idleTime() {
        return this.$$$config.idleTime;
    }
    //--------------------------------------------------------------------------
    // worker 任務的時限
    // time = 0 沒時限
    set timeout(time) {
        time = Number(time);

        if (time < 0) {
            throw new Error("timeout must be >= 0");
        }

        this.$$$config.timeout = time;
    }

    get timeout() {
        return this.$$$config.timeout;
    }
    //--------------------------------------------------------------------------
    set ['_path'](path) {
        this.$$$config['_path'] = path;
    }

    get ['_path']() {
        const _ = require('_extension')['_'];
        let defult_path = _.$$$extension['_path'];
        return (this.$$$config['_path'] || defult_path);

    }
    //--------------------------------------------------------------------------
    set extensionPath(path) {
        this.$$$config.extensionPath = path;
    }

    get extensionPath() {
        const _ = require('_extension')['_'];
        let defult_path = _.$$$extension['extensionPath'];
        return (this.$$$config['extensionPath'] || defult_path);
    }
    //--------------------------------------------------------------------------

    set importScriptList(list) {

        if (typeof list == 'string') {
            list = [list];
        } else {
            list = Array.from(list);
        }


    }

    get importScriptList() {
        return this.importScriptList;
    }
}

module.exports = (() => {
    debugger;
    return Config.getInstance();
})();