// worker 的本體
const {
    isMainThread,
    parentPort,
    workerData
} = require('_extension/worker/node_modules/worker_threads');

//--------------------------------------
let {
    "_path": _path,
    extensionPath,
    importScriptList
} = workerData;


// 引入 scripts
let _;

{
    // 引入模組    
    const _ = require(extension1Path).expand(_path);

    importScriptList.forEach((path) => {
        require(path)(_path);
    });

    //--------------------------------------
    if (!isMainThread) {
        parentPort.on('message', function (e) {
            // debugger;

            let data = e || {};
            //----------------------------

            let {
                // 命令
                action,
            } = data;

            switch (action) {
                case "exit":
                    // 收到終結訊號
                    process.exit();
                    break;
                default:
                    doWork(data);
                    break;
            }
        });
        //================================================  

        // 通知已初始化完畢
        parentPort.postMessage({
            initialized: true
        });
    }
}

function doWork(data) {
    let {
        // _命令
        command,
        args,
        funList,
        id,
        jobID,
    } = data;

    // 參數
    args = args || [];
    funList = funList || [];

    if (_ == null) {
        throw new Error('(lodash|underscore) load error');
    }
    // worker 接運算任務
    // debugger;

    if (!command && typeof _[command] != 'function') {
        throw new TypeError(`_ no this function[${command}]`);
    }


    // debugger;
    // _ 的運算
    let res = _[command].apply(_, args);
    //----------------------------
    if (res instanceof Promise) {
        res.then(function () {
            forTest(res, true);
        });

        res.catch(function (e) {
            let err;

            if (!(e instanceof Error)) {
                err = new Error(e);
            }
            throw err;
        });

    } else {
        forTest(res, true);
    }
    //----------------------------

    function forTest(res, test) {

        if (test) {
            setTimeout(function () {

                parentPort.postMessage({
                    res: res
                });
            }, 1000);
        } else {

            separentPort.postMessage({
                res: res
            });
        }
    }
}