const $file = {};
module.exports = $file;

const $fs = require('fs');
const $path = require('path');

{
    $file.file_exists = async function () {

    };

    $file.file_exists_sync = function (path) {
        return $fs.existsSync(path);
    };

    $file.is_file = async function () {

    };

    $file.is_file_sync = function () {

    };

    $file.file_get_contents = async function (filepath) {
        let content = await new Promise((res, rej) => {
            $fs.readFile(filepath, 'utf8', (err, data) => {
                if (err == null) {
                    res(data);
                } else {
                    rej(err);
                }
            });
        });
        return content;
    };

    $file.file_get_contents_sync = function (filepath) {
        return $fs.readFileSync(filepath, 'utf8');
    };
}