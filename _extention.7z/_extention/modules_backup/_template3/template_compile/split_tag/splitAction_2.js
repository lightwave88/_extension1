const $tool = require('../../tool.js');
const $config = require('../../config.js');
const $is_singleActionTags = require('./is_singleActionTag.js');


const REPLACE_ACTIONNAME = /@action(?=[:])/;

// 判斷是否是 <% %>, <action:...> 的標籤頭
const ACTION_TAG_HEAD_REG = /(<@action:(\w+?))(?=\/|>|\s)/;

const TAG_HEAD_REG = /<(\/)?([^\s/]+?)(?=(\s|>|\/))/;

// 驗證標籤用
const REG_1 = /<[/]?@action:(\w+)/;
//==============================================================================
// tag 格式錯誤
class TagFormatError extends Error {
    constructor(msg) {
        super(msg);
    }

}
//==============================================================================

class SplitAction {

    static main(content, actionMap) {
        debugger;

        let remain = content;
        const contentList = [];

        while (remain.length) {
            debugger;

            // remain 進入分析
            let res;

            try {
                // 分析是否有 <action> 標籤
                res = FindAction.findStart(remain);
            } catch (error) {
                if (error instanceof TagFormatError) {
                    // 出現格式錯誤
                    contentList.push(remain);
                    break;
                } else {
                    throw error;
                }
            }
            //-------------
            if (res == null) {
                // 沒 <ation> 標籤
                contentList.push(remain);
                break;
            }

            let {
                node,
                leftContext,
                rightContext
            } = res;

            node = addNode(node, actionMap);
            contentList.push(leftContext);
            contentList.push(node);
            remain = rightContext;
        } //endWhile

        return contentList.join('');
    }
}

SplitAction.symbol_head = '[@A(';
SplitAction.symbol_foot = ')@]';

module.exports = SplitAction;
//==============================================================================

class FindAction {

    static findStart(content, parent, attributes) {
        const o = new FindAction(content, parent, attributes);
        return o.findStart();
    }

    static findChilds(content, parent, attributes) {
        const o = new FindAction(content, parent, attributes);
        return o.findChilds();
    }
    //--------------------------------------------------------------------------
    constructor(content, parent, attributes) {
        this.content = content;
        this.parent = parent;
        this.result = {
            node: undefined,
            leftContext: undefined,
            rightContext: undefined,
        };

        // 是否是單標籤
        this.is_singleTag = false;
        this.tagList = [];

        this.action;
        this.remain = '';
        this.attributes = {};
        this.childList = [];

        //------------------

        Object.assign(this.attributes, attributes);
    }
    //--------------------------------------------------------------------------
    // 找出<action>標籤
    //
    // 找尋標籤的起始
    findStart() {
        debugger;

        (() => {
            if (!this._findHeadStart()) {
                this.result = null;

                return;
            }

            if (!this._findHeadEnd()) {
                throw new TagFormatError();
            }
            //-------------

            if (this.is_singleTag) {
                // 此 <action> 是單標籤
                return;
            }

            // 會進入遞迴分析
            this._findChilds();
        })();

        if (this.result != null) {
            this.result.node = setNode(this);
        }

        if (this.parent == null) {
            this._sortOutChilds();
        }

        return this.result;
    }
    //--------------------------------------------------------------------------
    
    
    // 找出<action>標籤
    //
    // 已經抓到標籤的頭
    // 尚未確定頭的關閉
    findChilds() {
        debugger;

        this.remain = this.content;

        // 會進入遞迴分析
        this._findChilds();

        return this.result;
    }
    //--------------------------------------------------------------------------
    // 找尋標籤的起始
    //
    _findHeadStart() {
        debugger;

        const reg_1 = transformReg(ACTION_TAG_HEAD_REG, 'gu');

        let res = reg_1.exec(this.content);
        if (res == null) {
            return false;
        }

        let {
            1: head,
            2: action,
            index
        } = res;

        let lastIndex = index + head.length;

        this.result.leftContext = this.content.substring(0, index);
        this.action = action;
        this.remain = this.content.substring(lastIndex);

        return true;
    }
    //--------------------------------------------------------------------------
    // 確定起頭標籤的結束
    //
    _findHeadEnd() {
        debugger;

        let res = $tool.find_tagEnd(this.remain);
        if (res == null) {
            return false;
        }
        //------------------
        let {
            index,
            attributes,
            single,
        } = res;

        if (/^param$/.test(this.action)) {
            // <action:param> 的 attributes 必須整理
            attributes = sortOutParamAttributes(attributes);
        }
        debugger;

        Object.assign(this.attributes, attributes);
        this.remain = this.remain.substring((index + 1));

        if ($is_singleActionTags.includes(this.action)) {
            this.is_singleTag = true;
        } else if (single) {
            this.is_singleTag = true;
        } else {
            this.is_singleTag = false;
        }
        //------------------
        if (this.is_singleTag) {
            this.rightContext = this.remain;
        }

        return true;
    }
    //--------------------------------------------------------------------------
    // 會進入遞迴
    _findChilds() {
        debugger;

        const result = this.result;
        const reg_1 = transformReg(TAG_HEAD_REG);
        const reg_2 = transformReg(REG_1);

        let res;

        let remain = this.remain;


        debugger;
        debugger;

        // 找尋合乎規格的標籤開頭
        while (null != (res = reg_1.exec(remain))) {
            debugger;

            let {
                0: match,
                1: foot,
                2: tagName,
                index
            } = res;

            foot = !!foot;

            // 分析抓到的標籤頭
            let needCheck = remain.substring(index);

            //-------------
            // 標籤格式是否正確
            let res_1 = $tool.find_tagEnd(needCheck);

            if (res_1 == null) {
                throw new TagFormatError();
            }

            let {
                index: tagEnd_index,
                single,
                attributes
            } = res_1;

            //-------------
            let res_2;

            // 檢查是 <html> 還是 <action> 標籤
            if (null == (res_2 = reg_2.exec(match))) {
                // 一般 <html>
                if (this.parent == null) {
                    // 狀況
                    // <action>未關閉且緊接著<div>
                    // 視作關閉

                    if (this.childList.length) {

                    } else {
                        // 單標籤被誤判為雙標籤
                        result.rightContext = remain;
                        return true;
                    }

                }
                throw new Error(
                    `(${tagName}) can't inside action_tag`);
            }
            //-------------
            let {
                1: action
            } = res_2;

            needCheck = needCheck.substring(tagEnd_index + 1);
            //------------------
            if (single) {

                if (/^param$/.test(action)) {
                    // <action:param> 的 attributes 必須整理
                    attributes = sortOutParamAttributes(attributes);
                }

                let node = setNode({
                    action,
                    attributes
                });

                this.childList.push(node);

                remain = needCheck;
            } else if (foot) {

                let {
                    index
                } = res;

                if (Object.is(this.action, action)) {

                    // 結束
                    // 結束
                    // 結束
                    result.rightContext = needCheck;
                    return true;
                }
                // 沒被捕捉到的</action>
                throw new Error(
                    `error end(${action}) after (${this.action})`);
            } else {


                // 遞迴
                let res_2 = FindAction.findChilds(needCheck, this, attributes);

                debugger;
                let {
                    node,
                    rightContext,
                } = res_2;

                this.childList.push(node);

                remain = rightContext;
            }

        } // endWhile
        //------------------
        console.log(remain);

        return false;
    }
    //--------------------------------------------------------------------------
    // 整理 childNode
    _sortOutChilds() {
        debugger;
        console.dir(this.childList);
    }
}


//==============================================================================
/**
 * 有關於 <action:> 標籤的轉換
 * 預設是 <jsp:...>
 * 使用者可自定
 *
 * @param {*} reg
 * @param {*} options
 */
function transformReg(reg, options) {
    const action_name = $config.get("action_name");

    let _reg = reg.source;

    const replace_reg = RegExp(REPLACE_ACTIONNAME.source, 'g');

    _reg = _reg.replace(replace_reg, `${action_name}`);

    if (!options) {
        options = '';
    }

    return RegExp(_reg, options);
}
//----------------------------
function addNode(node, actionMap) {
    let index = actionMap.length;
    actionMap.push(node);

    let replace =
        `${SplitAction.symbol_head}${index}${SplitAction.symbol_foot}`;
    return replace;
}
//----------------------------
function setNode({
    action = null,
    attributes = null,
    childList = []
}) {

    attributes = Object.assign({}, attributes);

    return {
        action, attributes, childList
    };
}
//----------------------------
function sortOutParamAttributes(attributes) {
    let res = {};
    let key;
    let value = '';

    if ('name' in attributes) {
        key = attributes['name'];

        if ('value' in attributes) {
            value = attributes['value'];
        }

        res[key] = value;
    }

    return res;
}
