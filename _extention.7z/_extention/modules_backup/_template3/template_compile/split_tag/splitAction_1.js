const $tool = require('../../tool.js');
const $config = require('../../config.js');
const $is_singleActionTags = require('./is_singleActionTag.js');


const REPLACE_ACTIONNAME = /@action(?=[:])/;

// 判斷是否是 <% %>, <action:...> 的標籤頭
const ACTION_TAG_HEAD_REG = /<@action:(\w+?)(?:(\/>)|>|\b)/;

const TAG_HEAD_REG = /<(\/)?(\S+?)(?=(\s|>|\/>))/;

// 驗證標籤用
const REG_1 = /<[/]?@action:(\w+)/;
//==============================================================================
// tag 格式錯誤
class TagFormatError extends Error {
    constructor(msg) {
        super(msg);
    }

}
//==============================================================================

class SplitAction {

    static main(_content, actionMap) {
        debugger;

        const content = _content;
        const reg_1 = transformReg(ACTION_TAG_HEAD_REG, 'gu');

        const contentList = [];

        let lastIndex = 0;
        let findTimes = 0;

        let node, reg_res;

        // 尋找<action>的開頭
        // 直到找不到
        while ((reg_res = reg_1.exec(content)) != null) {
            debugger;

            findTimes++;

            let {
                0: match,
                1: action,
                2: is_end,
                index
            } = reg_res;

            // 非 <action> 的內容
            node = content.substring(lastIndex, index)
            contentList.push(node);

            lastIndex = reg_1.lastIndex;
            //------------------
            // 區分找出的是哪類

            if (is_end) {
                // 無用的 action_tag
                continue;
            }
            //------------------
            // 找到頭部
            // 但尚未確定是否正確關閉
            let remain = content.substring(lastIndex);

            // 找 action 是否正確結束
            const o = new SplitAction();

            let res;
            try {
                // 確定 action_tag 是否有正確結束
                res = o.findAction(action, remain);

                debugger;
            } catch (error) {
                debugger;
                if (error instanceof TagFormatError) {
                    // 標籤錯誤
                    // 不用再分析了
                    break;
                } else {
                    throw error;
                }
            }

            let {
                index: _index,
                node: _node
            } = res;

            let replace = addNode(_node, actionMap);
            // 取代原文本
            contentList.push(replace);

            lastIndex = lastIndex + _index + 1;
            reg_1.lastIndex = lastIndex;
        } // endWhile
        //------------------
        debugger;

        if (!findTimes) {
            // 啥都沒有
            contentList.push(content);
        } else {
            if (content[lastIndex] != null) {
                // 若還有尾部
                let str = content.substring(lastIndex);
                contentList.push(str);
            }
        }

        return contentList.join('');
    }
    //--------------------------------------------------------------------------
    constructor() {
        this.fn = SplitAction;
    }
    //--------------------------------------------------------------------------
    // 只需尋找一次
    findAction(actionName, _content) {
        debugger;

        if (/param[s]?/.test(actionName)) {
            // <action:param> <action:params>
            // 必須是子標籤
            throw new Error(`tag(${actionName}) must be child tag`);
        }


        this.actionName = actionName;
        this.content = _content;

        this.attributes = {};

        const r_value = {
            index: undefined,
            node: undefined,
        };

        let lastIndex;
        //-------------
        (() => {
            debugger;

            // 找 <action...(>)
            let res = $tool.find_tagEnd(this.content);

            if (res == null) {
                // 沒有正確閉合

                throw new TagFormatError();
                return;
            }
            //-------------
            // <action...(>)找到了
            let {
                index,
                attributes: attributes_1,
                is_end,
            } = res;

            lastIndex = index + 1;

            Object.assign(this.attributes, attributes_1);

            // 確定是單標籤還是雙標籤
            if ($is_singleActionTags.includes(this.actionName)) {
                r_value.index = index;

                return;
            }
            // 可以是單標籤或雙標籤
            if (is_end) {
                // 是單標籤
                // 不用再繼續找下去
                r_value.index = index;
                return;
            }
            //-------------
            // 是雙標籤
            let remain = this.content.substring(lastIndex);


            // 找 <action...>...(</action>)
            // 找後部
            res = this.fn._find_tagEnd(this.actionName, remain);

            //-------------
            // find
            let {
                index: end,
                attributes: attributes_2,
            } = res;

            Object.assign(this.attributes, attributes_2);
            r_value.index = (lastIndex + end);
        })();
        //-------------

        if (r_value.index != null) {
            r_value.node = setNode(this.actionName, this.attributes);
        }

        return r_value;
    }
    //--------------------------------------------------------------------------
    // 若不是單標籤，可能會有<params><param>標籤
    static _find_tagEnd(actionName, _content, loop = -1) {
        debugger;

        loop++;

        const content = _content;

        const reg_2 = transformReg(REG_1);

        const reg_1 = transformReg(TAG_HEAD_REG, 'g');

        // loop find tag

        const r_value = {
            index: undefined,
            attributes: {}
        };

        (() => {
            debugger;


            let res, lastIndex;

            let paramList = [];
            while (null != (res = reg_1.exec(content))) {
                debugger;

                let {
                    0: match,
                    1: foot,
                    2: tagName,
                    index
                } = res;

                lastIndex = reg_1.lastIndex;
                //-------------

                // 驗證 actionName 的合理性
                let res_1 = reg_2.exec(match);

                if (res_1 == null) {
                    // 不是 action 標籤
                    if (loop > 0) {
                        throw new Error(
                            `(${tagName})not action_tag after action_tag`
                        );
                    } else {
                        // 遇到 <html>
                        r_value.index = (index - 1);
                        break;
                    }
                }

                let {
                    1: action
                } = res_1;

                if (Object.is(actionName, action)) {
                    let c = content.substring(lastIndex);
                    let res = $tool.find_tagEnd(c);

                    if (res == null) {
                        // 標籤格式錯誤
                        throw new TagFormatError();
                    }

                    if (foot != null && foot.length) {
                        // 找到目標尾
                        // 正解
                        // 正解
                        r_value.index = lastIndex + res.index;
                        break;
                    }
                    throw new Error(`(${action})標籤不可套嵌`);

                } else if (/param/.test(action)) {
                    // 找 > 尾
                    let c = content.substring(lastIndex);

                    let res = $tool.find_tagEnd(c);

                    if (res == null) {
                        // 標籤沒有正確閉合
                        throw new TagFormatError();
                    }

                    let {
                        index, attributes
                    } = res;

                    attributes = sortOutAttributes(attributes);


                    Object.assign(r_value.attributes, attributes);
                    lastIndex = lastIndex + index + 1;

                } else if (/params/.test(action)) {
                    // 其他 action 標籤
                    let c = content.substring(lastIndex);
                    let res = $tool.find_tagEnd(c);

                    if (res == null) {
                        // 標籤格式錯誤
                        return;
                    }
                    let {
                        index
                    } = res;

                    lastIndex = index + 1;
                    let remain = content.substring(lastIndex);

                    // 遞迴
                    res = SplitAction._find_tagEnd(action, remain, loop);

                    let {
                        index: _index,
                        attributes
                    } = res;

                    Object.assign(r_value.attributes, attributes);
                    lastIndex = lastIndex + _index + 1;

                } else {
                    throw new Error(`no acceptable tag(${action})`);
                }

            } //endWhile
        })();

        return r_value;

    }
}

SplitAction.symbol_head = "[@A[";
SplitAction.symbol_foot = "]@]";

module.exports = SplitAction;
//==============================================================================
/**
 * 有關於 <action:> 標籤的轉換
 * 預設是 <jsp:...>
 * 使用者可自定
 *
 * @param {*} reg
 * @param {*} options
 */
function transformReg(reg, options) {
    const action_name = $config.get("action_name");

    let _reg = reg.source;

    const replace_reg = RegExp(REPLACE_ACTIONNAME.source, 'g');

    _reg = _reg.replace(replace_reg, `${action_name}`);

    if (!options) {
        options = '';
    }

    return RegExp(_reg, options);
}
//----------------------------
function addNode(node, actionMap) {
    let index = actionMap.length;
    actionMap.push(node);

    let replace =
        `${SplitAction.symbol_head}${index}${SplitAction.symbol_foot}`;
    return replace;
}
//----------------------------
function setNode(action, attributes) {
    const node = {
        name: action,
        attributes: attributes
    };

    return node;
}

function sortOutAttributes(attributes) {
    let res = {};
    let key;
    let value = '';

    if ('name' in attributes) {
        key = attributes['name'];

        if ('value' in attributes) {
            value = attributes['value'];
        }

        res[key] = value;
    }

    return res;
}
