// 父模組是(split_tag.js)

const $setting = require('./setting.js');
const $setNode = $setting["setNode"]["c"];

// 找 <% 的標籤頭
const TAG_START_REG = /<%[=]?/;

const TAG_END_REG = /%>/;

const SCRIPT_START = /<script[^>]+class=(["'])_\1[\s\S]*?>/;

const SCRIPT_END = /<\/script>/;
/**
 * 把命令分離出來
 * <% %>, <%- %>, <%= %>, <js:action...>
 */
class SplitCommand {

    static main(content, parent) {
        const o = new SplitCommand(content, parent);
        return o.main();
    }
    //--------------------------------------------------------------------------
    constructor(content, parentModule) {
        // debugger;

        this.fn = SplitCommand;
        this.parentModule = parentModule;
        this.content = content;

        // 要返回的文本
        this.contentList = [];
        this.commandBlocks = this.parentModule.commandBlocks;

        // 處理字串的位置
        this.lastIndex = 0;
    }
    //--------------------------------------------------------------------------
    // API

    main() {
        // debugger;

        let remain = this.content;

        while (remain.length > 0) {

            let { nodes, remain: _remain } = this._find(remain);

            nodes.forEach((str) => {
                this.contentList.push(str);
            });

            remain = _remain;
        } //endWhile

        let r_value = this.contentList.join('');
        this.contentList.length = 0;

        return r_value;
    }

    //--------------------------------------------------------------------------
    // 分割 <script class="_">
    splitScript() {
        let remain = this.content;

        while (remain.length > 0) {
            let { nodes, remain: _remain } = this._find_1(remain);
        }

    }
    //--------------------------------------------------------------------------

    // 找尋 <% %>
    _find(_content) {
        const content = _content;

        const nodeList = [];

        const r_value = {
            remain: "",
            nodes: nodeList
        };

        let reg_1 = RegExp(TAG_START_REG, 'g');
        let res_1 = reg_1.exec(content);

        if (res_1 == null) {
            // 沒找到任何 <%* %>
            this._addHtmlNode(content, nodeList);
            return r_value;
        }
        //------------------
        let {
            0: command_name,
            index: index_1
        } = res_1;

        let lastIndex = reg_1.lastIndex;
        let start = lastIndex;

        const prev_node = content.substring(0, index_1);
        //------------------
        // 找 %>

        let reg_2 = RegExp(TAG_END_REG, 'g');
        reg_2.lastIndex = lastIndex;

        res_1 = reg_2.exec(content);

        if (res_1 == null) {
            // 沒找到 %>
            let errorContent = content.substring(index_1, (index_1 + 19));
            throw new Error(errorContent);
        }
        //------------------
        let {
            index: end
        } = res_1;

        lastIndex = reg_2.lastIndex;

        let command = content.substring(start, end);
        command = this._setNode(command_name, command);
        //------------------

        nodeList.push(prev_node);
        nodeList.push(command);

        r_value.remain = content.substring(lastIndex);

        return r_value;
    }
    //--------------------------------------------------------------------------
    // 分離 <script class="_">
    _find_1(_content) {
        const content = _content;

        const nodeList = [];

        const r_value = {
            remain: "",
            nodes: nodeList
        };

        const $reg_1 = RegExp(SCRIPT_START, "gu");
        
        let res = $reg_1.exec(content);
        
        if(res == null){
            // 沒找到任何 <%* %>
            this._addHtmlNode(content, nodeList);
            return r_value;
        }
        const $reg_2 = RegExp(SCRIPT_END, "gu");

    }
    //--------------------------------------------------------------------------
    // 把命令文本用簡單的文本取代
    // 避免對後續的分析造成太複雜
    _setNode(command_name, content) {
        // debugger;

        // console.log('command(%s)', content);

        let index = this.commandBlocks.length;

        let { node, replace } = $setNode(index, {
            name: command_name,
            content
        });

        this.commandBlocks.push(node);

        return replace;
    }
    //--------------------------------------------------------------------------
    _addHtmlNode(content, nodeList) {
        if (content == null || !content.length) {
            return;
        }
        nodeList.push(content);
    }
}

module.exports = SplitCommand;
