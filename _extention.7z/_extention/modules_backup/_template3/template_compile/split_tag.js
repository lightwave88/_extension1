const $util = require('util');

const $GM = require('./gmodules.js');
const $tool = require('../tool.js');
const $file = require('../file.js');
const $path = require('path');
const $config = require('../config.js');


//-------------
const $splitCommand = require('./split_tag/splitCommand.js');
const $splitAction = require('./split_tag/splitAction.js');
const $splitJs = require('./split_tag/splitJs.js');

//-------------

const SPLIT_CONTENT = /\[@(\w+)\((\d+)\)@\]/;

/**
 * 給與內文
 * 然後分離出 nodeList
 */
class Splite_tag {

    static async main(content) {

    }

    //--------------------------------------------------------------------------
    static main_sync(content, userOptions) {
        debugger;

        let nodeList;

        const o = new Splite_tag(content, userOptions, true);

        // 會把 content 分解成 nodeList
        nodeList = o.splitTag_sync();
        //------------------
        return nodeList;
    }
    //--------------------------------------------------------------------------
    constructor(content, userOptions, checkMerge) {
        debugger;
        this.fn = Splite_tag;
        this.userOptions = userOptions;
        this.content = content;
        this.checkMerge = !!checkMerge;
        this.nodeList = [];
        //------------------
        this.commandBlocks = [];
        this.actionBlocks = [];
        this.jsBlocks = [];
    }
    //--------------------------------------------------------------------------
    /**
     * 主要的 API
     */
    async splitTag() {
        // 先把<script>分割出來
        this._splitScriptTag();

        // debugger;
        this._splitCommandTag();
        //=======================
        if (this.checkMerge == true) {
            const {
                include: $IncludeClass
            } = $GM.get('actionNode');

            // 檢查 include_node
            let has_include_node;
            do {
                debugger;
                has_include_node = false;
                let copy_nodeList = [];
                /**
                 * 檢查 include_node
                 */


                this.nodeList = copy_nodeList;
            } while (has_include_node);
        }

        return this.nodeList;
    }
    //--------------------------------------------------------------------------
    /**
     * 主要的 API
     */
    splitTag_sync() {
        debugger;

        //------------------
        // 從最小單位開始拆起
        // 比較快

        let content = this.content;

        // 把命令分解出來 <%* %>
        // 最高優先性與原子性
        // 去掉文本命令，防止對後續的干擾
        content = this._splitCommand(content);

        debugger;
        // 分離出 <action>
        // 去掉文本命令，防止對後續的干擾
        content = this._splitAction(content);

        // 分離 <script>
        content = this._splitJs(content);

        debugger;
        this._buildNodeList(content, this.nodeList);

        this._instance_stringNodes(this.nodeList);

        console.dir(this.nodeList);

        // return this.nodeList;
        //=======================
        debugger;

        let nodeList = this.nodeList.slice();
        /**
         * 處理靜態 include
         * 處理 includeNode 若有的話
         */
        if (this.checkMerge == true) {

            // 取得 includeNode.class
            const {
                merge: $MergeClass
            } = $GM.get('nodeList_3');

            // 檢查 include_node
            let has_merge_node;

            do {
                debugger;
                has_merge_node = false;
                let copy_nodeList = [];
                /**
                 * 檢查 include_node
                 */
                nodeList.forEach((node) => {
                    debugger;
                    if (!(node instanceof $MergeClass)) {
                        copy_nodeList.push(node)
                    } else {
                        // 有 mergeNode
                        has_merge_node = true;

                        // 根據 include.page 取得 include 的內文
                        let content = this._getIncludeContent(node);

                        // 將 mergeNode 的內文,解析成 nodeList
                        // 不要分析 includeNode
                        const o = new Splite_tag(content, this.options, false);
                        debugger;

                        let nodes = o.splitTag_sync();

                        nodes.forEach((n) => {
                            copy_nodeList.push(n);
                        });

                    }
                });

                nodeList = copy_nodeList;
            } while (has_merge_node);
        }

        this.nodeList.length = 0;

        return nodeList;
    }
    //--------------------------------------------------------------------------
    // 檢查 <script> 的內容
    _splitScriptContent(content) {
        // 把命令分解出來 <%* %>
        // 最高優先性與原子性
        // 去掉文本命令，防止對後續的干擾
        content = this._splitCommand(content);

        let nodeList = [];

        debugger;
        // 分離出 <action>
        // 去掉文本命令，防止對後續的干擾
        content = this._splitAction(content);

        this._buildNodeList(content, nodeList);

        this._instance_stringNodes(nodeList);

        return nodeList;
    }
    //--------------------------------------------------------------------------
    _splitCommand(content) {
        // debugger;
        let _content = $splitCommand.main(content, this);

        console.log('----------------');
        console.log('splitCommand>>');
        console.log(_content);
        console.log($util.inspect(this.commandBlocks));
        return _content;
    }

    _splitAction(content) {
        let _content = $splitAction.main(content, this);

        console.log('----------------');
        console.log('splitAction>>');
        console.log(_content);
        console.log($util.inspect(this.actionBlocks));
        return _content;
    }

    _splitJs(content) {
        let _content = $splitJs.main(content, this);

        console.log('----------------');
        console.log('splitJavascript');
        console.log(_content);
        console.log($util.inspect(this.jsBlocks));
        return _content;
    }
    //--------------------------------------------------------------------------
    // 會有遞迴
    _buildNodeList(content, nodeList) {

        // const nodeList = this.nodeList;

        let remain = content;

        // 抽取[C, A, J]代碼
        while (remain.length > 0) {
            debugger;

            const reg_1 = RegExp(SPLIT_CONTENT, 'g');

            let res = reg_1.exec(remain);

            if (res == null) {
                nodeList.push(remain);
                break;
            }
            //------------------
            let {
                0: match,
                1: type,
                2: key,
                index
            } = res;

            let node = remain.substring(0, index);
            if (node.length > 0) {
                nodeList.push(node);
            }

            let lastIndex = reg_1.lastIndex;

            // 形成正式節點
            let nodes = this._getNode(type, key);

            nodes.forEach((n) => {
                nodeList.push(n);
            });

            remain = remain.substring(lastIndex);
        } // endWhile

    }
    //--------------------------------------------------------------------------
    /**
     * async, sync
     * 取得 includeNode.content
     *
     * @param {*} sync
     * @param {*} mergeNode
     */
    _getIncludeContent(mergeNode) {
        debugger;

        // 取得 include_page.url
        let page = mergeNode.getPage();

        let {
            sync, include_dir
        } = this.userOptions;

        if (!$path.isAbsolute(page)) {
            if (include_dir == null) {
                throw new Error("no set include_dir");
            }
            page = $path.resolve(include_dir, page);
        }
        //------------------
        let res;
        if (sync) {
            // 同步
            res = $file.file_get_contents_sync(page);
        } else {
            // 非同步
            // 返回 promise
            res = $file.file_get_contents(page);
        }
        return res;
    }
    //--------------------------------------------------------------------------
    // 合併相鄰的 string.node
    _mergeStringNode(nodeList) {
        const clone_list = [];

        let prev = '';
        nodeList.forEach((node, i) => {

            if (typeof (node) == 'string') {
                prev += node;

                if (i == (nodeList.length - 1)) {

                    if (prev.length > 0) {
                        clone_list.push(prev);
                    }
                    prev = null;
                }

            } else {
                if (prev.length) {
                    clone_list.push(prev);
                    clone_list.push(node);
                    prev = '';
                }
            }
        });

        return clone_list;
    }
    //--------------------------------------------------------------------------
    _instance_stringNodes(nodeList) {
        let $class;

        nodeList.forEach((node, i) => {
            if (typeof (node) == 'string') {
                if ($class == null) {
                    let $classList = $GM.get('nodeList_1');
                    $class = $classList['html'];
                }

                nodeList[i] = new $class(this.userOptions, node);
            }
            return node
        });
    }
    //--------------------------------------------------------------------------
    // 把節點資料化為真實的輸出節點
    _getNode(type, key) {
        debugger;

        key = parseInt(key, 10);

        let node, $class;
        switch (type) {
            case 'A':
                {
                    const $actionClassList = $GM.get('nodeList_3');
                    let { name, params, childs } = this.actionBlocks[key];

                    $class = $actionClassList[name];

                    if ($class == null) {
                        throw new Error(`no these action tag ${name}`);
                    }

                    node = new $class(this.userOptions, this.commandBlocks, {
                        params,
                        childs
                    });
                }
                break;
            case 'C':
                {

                    const $commandClassList = $GM.get('nodeList_2');
                    let { name, content } = this.commandBlocks[key];

                    $class = $commandClassList[name];

                    if ($class == null) {
                        throw new Error(`no these command tag ${name}`);
                    }

                    node = new $class(this.userOptions, name, content);
                }
                break;
            case 'J':
                {
                    const $classList = $GM.get('nodeList_1');

                    let { content } = this.jsBlocks[key];
                    debugger;

                    if (true) {
                        $class = $classList['script'];
                        // 採用 template_string
                        // <script>的內容尚未分析
                        // 遞迴

                        node = [];
                        this._buildNodeList(content, node);

                        // 轉換 script 裡的節點
                        node = node.map((_node) => {
                            if (typeof (_node) == 'string') {
                                _node = new $class(this.userOptions, _node);
                            }
                            return _node;
                        });
                    } else {
                        // 不採用 template_string
                        $class = $classList['html'];
                        node = new $class(this.userOptions, content);
                    }
                }
                break;
        }

        node = (Array.isArray(node)) ? node : [node];
        return node;
    }
}

module.exports = Splite_tag;
