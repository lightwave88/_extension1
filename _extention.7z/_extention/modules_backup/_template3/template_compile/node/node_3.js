const $GM = require('_template3/template_compile/gmodules');
const Node_ABS = require('_template3/template_compile/node/abstratNode');
const $tool = require('../../tool.js');

//----------------------------
/**
 * <js:action>
 * 本模組的本體
 *
 */
const $export = {};
module.exports = $export;

class ActionNode_ABS extends Node_ABS {

    // 擴充用
    // 註冊各式 action.class
    static $$$addClass(name) {
        let $class = this;
        $export[name] = $class
    }
    //--------------------------------------------------------------------------
    constructor(userOptions, commandList = [], args = {}) {

        super(userOptions);

        let { params = {}, childs = [] } = args;

        this.commandList = commandList;
        this.childs = childs;
        this.params = Object.assign({}, params);

        this.$tool = $GM.get('tool');

        this.$$$buildChildNodes();
    }
    //--------------------------------------------------------------------------
    // 工具涵式
    // 還原 attr 裏的 command 
    // 重要功能
    static $$$attr_mergeCommand(content, obj) {
        if (obj == null) {
            throw new Error("must assign object");
        }
        const commandList = obj.commandList;

        if (commandList == null) {
            throw new Error("obj no commandList attribute");
        }
        return $tool.attr_mergeCommand(content, commandList);
    }
    //--------------------------------------------------------------------------
    // 工具涵式
    // 基本 <action> 除了 <param><params>外不該有其他子節點
    $$$buildChildNodes() {
        // console.log("buildChildNodes");
        this.childs = this.childs.map((node) => {
            debugger;

            console.log("buildChildNodes>>");
            let { name, params, childs } = node;
            if (!(name in $export)) {
                throw new Error(`no this actionTag(${name})`);
            }

            $class = $export[name];

            // 會進入遞迴
            return (new $class(this.userOptions, params, childs, this.commandList));
        });
    }
}

//==============================================================================
{
    /**
     * 頁面在 render 前就先合并
     * page_url 是靜態，編譯前即決定
     * 
     * 可獲取父文件的變數
     * 與父文件在相同的解析範圍内
     */
    class MergeNode extends ActionNode_ABS {
        constructor(userOptions, params, childs, commandList) {
            super(userOptions, params, childs, commandList);

            this.fn = MergeNode;
            this.page;

            this._checkParams();

            this._setPage();
        }
        //----------------------------------------------------------------------
        _checkParams() {
            let {
                page
            } = this.params;
            if (!page) {
                throw new Error(`<action:include> no set page`);
            }
            this.page = page;
        }
        //----------------------------------------------------------------------
        _setPage() {
            const $path = require("path");
            let include_dir = this.userOptions["include_dir"];
            this.page = $path.resolve(include_dir, this.page);
        }
        //----------------------------------------------------------------------
        getPage() {
            return this.page;
        }
        //----------------------------------------------------------------------
        $$$printCommand() {
            throw new Error('includeNode no $$$printCommand()');
        }

        toString() {
            return `[action:include(page="${this.page}")]`;
        }
    }

    MergeNode.$$$addClass("merge");
}

//==============================================================================
{

    /**
     * page_url 可以根據上下文的變數動態取得
     * 
     * 無法獲取父文件的變數(但可人爲傳遞)
     * 與父文件在不同的解析範圍内
     * 
     * 在解析時才能確定引入的内容
     */
    class IncludeNode extends ActionNode_ABS {

        constructor(userOptions, params, childs, commandList) {
            super(userOptions, params, childs, commandList);

            this.fn = IncludeNode;

            this._buildContext();
        }
        //----------------------------------------------------------------------
        _buildContext() {
            debugger;

            if (!('page' in this.params)) {
                throw new Error("include no set page");
            }

            let page = this.params['page'];
            page = this.fn.$$$attr_mergeCommand(page, this);

            let data = 'null';
            if ('data' in this.params) {
                data = this.fn.$$$attr_mergeCommand(this.params['data'], this);
            }

            this.context = `\n$page.include(${page}, ${data});\n`;
        }
        //----------------------------------------------------------------------
        $$$printCommand() {
            return this.context;
        }
    }

    IncludeNode.$$$addClass("include");

}
//==============================================================================
{
    /**
     * <js:require>
     * 解析最慢
     *
     * page_url 可以根據上下文的變數動態取得
     * 
     * 可獲取父文件的變數
     * 因爲在同一個解析範圍内
     * 
     * 在解析時才能確定引入的内容
     */
    class RequireNode extends ActionNode_ABS {

        constructor(userOptions, params, childs, commandList) {
            super(userOptions, params, childs, commandList);

            this.fn = RequireNode;
            this.require_args;
            this.context = "";

            this._getOptions();

            this._buildContext();
        }
        //----------------------------------------------------------------------
        _getOptions() {
            // debugger;            
            let options = '';

            let keys = Object.getOwnPropertyNames(this.params);

            if (!("page" in this.params)) {
                throw new Error('<action:require no page args');
            }

            keys.forEach((key) => {
                let value = this.fn.$$$attr_mergeCommand(this.params[key], this);
                options += '\n' + JSON.stringify(key) + ":" + value + ',';
            });

            this.require_args = options;
        }
        //----------------------------------------------------------------------
        _buildContext() {
            let sync = this.userOptions.sync;

            let status_1 = '';
            let status_2 = '';

            if (!sync) {
                status_1 = 'await ';
                status_2 = 'async ';
            }
            let content = 'debugger;\n';


            content += `\n${status_1}$page.requirePage({${this.require_args}\n});
                debugger;
            `;

            // 另一種做法
            // content += `eval($page.getRequireContent());\n`;

            content += `
            // 構建動態指令            
            $page.$$$reguireCommand = eval(\`(${status_2}function(){
                debugger;\n
                $page.$$$reguireCommand = null;
                $\{$page.$$$getRequireContent()}
            })\`);
            
            debugger;
            // 執行動態指令
            ${status_1}$page.$$$reguireCommand.call(this);\n`;

            this.context = content;
        }
        //----------------------------------------------------------------------
        $$$printCommand() {
            return this.context;
        }

        toString() {
            return `[action:require(${this.context})]`;
        }
    }

    RequireNode.$$$addClass("require");
}
//==============================================================================
{
    // for test
    class TestNode extends ActionNode_ABS {

        constructor(userOptions, params, childs, commandList) {
            super(userOptions, params, childs, commandList);
            this.fn = TestNode;
            this.options;
            this.context = '';

            this._getOptions();
        }
        //----------------------------------------------------------------------
        _getOptions() {
            debugger;


            let keys = Object.getOwnPropertyNames(this.params);

            keys.forEach((key) => {
                debugger;
                let value = this.fn.$$$attr_mergeCommand(this.params[key], this);
                // value = $tool.escapeHTML(value);

                let _key = JSON.stringify(key);
                // _key = $tool.escapeHTML(_key);

                this.context += '<p>' + _key + " : " + value + "</p>";
            });
            this.context = `
            <div class="action_test">
                <p>action:test</p>
                ${this.context}
            </div>`;

            this.context = `$out.print(${JSON.stringify(this.context)});\n`;

        }
        //----------------------------------------------------------------------
        $$$printCommand() {
            return this.context;
        }

        toString() {

            let content = {
                params: this.params,
                childs: this.childs
            };

            content = JSON.stringify(content);

            return `[action:test(${content})]`;
        }
    }

    TestNode.$$$addClass("test");
}

{
    class ConsoleNode extends ActionNode_ABS {
        constructor(userOptions, params, childs, commandList) {
            super(userOptions, params, childs, commandList);

            this.fn = ConsoleNode;
            this.options;
            this.context = '';


            this._getOptions();
        }

        _getOptions() {
            // debugger;

            let keys = Object.getOwnPropertyNames(this.params);

            keys.forEach((key) => {
                let value = this.fn.$$$attr_mergeCommand(this.params[key], this);
                // value = $tool.escapeHTML(value);

                let _key = JSON.stringify(key);
                // _key = $tool.escapeHTML(_key);

                this.context += _key + " : " + value + ",\n";
            });

            this.context = "{" + this.context + "}";

            this.context = `
            $out.print(${JSON.stringify(`<p class="action_console">`)});\n
            $out.print(${this.context});\n
            $out.print("</p>");\n
            `;

        }

        $$$printCommand() {
            return this.context;
        }
    }

    ConsoleNode.$$$addClass("console");
}