const $tool = require('../../tool.js');
////////////////////////////////////////////////////////////////////////////////
//
// 節點
//
////////////////////////////////////////////////////////////////////////////////

/**
 * 抽象類
 */
class Node_ABS {
    constructor(userOptions = {}) {
        this.userOptions = userOptions;
    }
    //----------------------------
    // 最主要的
    $$$printCommand() {
        throw new Error('$$$printCommand() no override');
    }
    //----------------------------
    // 脫逸 `
    // 會對 template.compile 發生問題
    static $$$escape_templateString(content) {
        return $tool.escape_templateString(content);
    }
    //----------------------------
    // 
    static $$$escape_html(content){
        return $tool.escape_html(content);
    }
}

module.exports = Node_ABS;